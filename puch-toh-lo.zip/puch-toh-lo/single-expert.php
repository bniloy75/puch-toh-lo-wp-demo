<?php
/**
 * Single expert profile.
 *
 * @package PuchTohLo
 */

get_header();

while ( have_posts() ) :
	the_post();

	$expert_id = get_the_ID();
	$name      = get_the_title();
	$first     = explode( ' ', preg_replace( '/^Dr\.\s*/', '', $name ) );
	$first     = $first[0];
	$photo     = ptl_image_url( $expert_id, 'photo' );
	$languages = ptl_lines( $expert_id, 'languages' );
	$focus     = ptl_lines( $expert_id, 'focus' );
	$hosted    = array();

	foreach ( ptl_get_events( 'ASC' ) as $event ) {
		if ( (int) ptl_meta( $event->ID, 'host', 0 ) === (int) $expert_id && ! ptl_is_past( ptl_meta( $event->ID, 'start' ) ) ) {
			$hosted[] = $event;
		}
	}

	$others = array();
	foreach ( ptl_get_experts() as $expert ) {
		if ( (int) $expert->ID !== (int) $expert_id && count( $others ) < 3 ) {
			$others[] = $expert;
		}
	}
	?>
	<div class="expert-detail">
		<div class="container">
			<nav class="breadcrumb" aria-label="Breadcrumb">
				<a href="<?php echo esc_url( ptl_archive_url( 'expert' ) ); ?>">The directory</a>
				<span aria-hidden="true">/</span>
				<span><?php echo esc_html( $name ); ?></span>
			</nav>

			<header class="expert-profile-head">
				<div class="expert-profile-media">
					<?php if ( $photo ) : ?>
						<img src="<?php echo esc_url( $photo ); ?>" alt="Portrait placeholder for <?php echo esc_attr( $name ); ?>">
					<?php else : ?>
						<span class="expert-profile-initials" style="background-color: <?php echo esc_attr( ptl_meta( $expert_id, 'tone', '#8a6a55' ) ); ?>" aria-hidden="true">
							<?php echo esc_html( ptl_meta( $expert_id, 'initials', 'PT' ) ); ?>
						</span>
					<?php endif; ?>
					<?php if ( ptl_flag( $expert_id, 'sample' ) ) : ?><?php ptl_sample_badge(); ?><?php endif; ?>
				</div>

				<div class="expert-profile-copy">
					<div class="expert-profile-eyebrow">
						<?php ptl_tag( ptl_meta( $expert_id, 'group', 'Practitioner' ) ); ?>
						<span class="expert-role-line"><?php echo esc_html( ptl_meta( $expert_id, 'role' ) ); ?></span>
					</div>
					<h1 class="page-title"><?php echo esc_html( $name ); ?></h1>
					<p class="expert-profile-headline"><?php echo esc_html( ptl_meta( $expert_id, 'headline' ) ); ?></p>

					<div class="profile-facts">
						<span>
							<?php echo ptl_icon( 'map-pin', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<?php echo esc_html( ptl_meta( $expert_id, 'city' ) ); ?> · <?php echo esc_html( ptl_meta( $expert_id, 'mode' ) ); ?>
						</span>
						<span>
							<?php echo ptl_icon( 'languages', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<?php echo esc_html( implode( ', ', $languages ) ); ?>
						</span>
						<span>
							<?php echo ptl_icon( 'wallet', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<?php echo esc_html( ptl_meta( $expert_id, 'fee' ) ); ?>
						</span>
					</div>

					<div class="profile-focus">
						<?php foreach ( $focus as $item ) : ?>
							<span class="chip chip--static"><?php echo esc_html( $item ); ?></span>
						<?php endforeach; ?>
					</div>

					<div class="profile-actions">
						<a href="<?php echo esc_url( ptl_page_url( 'ask' ) . '?path=support&practitioner=' . get_post_field( 'post_name', $expert_id ) ); ?>" class="btn btn-primary">
							Ask to connect
							<?php echo ptl_icon( 'arrow-up-right', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</a>
						<?php if ( $hosted ) : ?>
							<a href="<?php echo esc_url( get_permalink( $hosted[0] ) ); ?>" class="btn btn-outline">
								Meet at <?php echo esc_html( ptl_meta( $hosted[0]->ID, 'kind', 'circle' ) ); ?>
							</a>
						<?php endif; ?>
					</div>

					<p class="sample-disclaimer">
						Illustrative profile for design review. The name, credentials, fees and
						availability are placeholders — not a real practitioner listing.
					</p>
				</div>
			</header>

			<div class="expert-profile-body">
				<div class="expert-profile-main">
					<section class="prose-block">
						<h2>About</h2>
						<?php echo apply_filters( 'the_content', get_the_content() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</section>

					<section class="prose-block">
						<h2>How <?php echo esc_html( $first ); ?> works</h2>
						<ul class="check-list">
							<?php foreach ( ptl_lines( $expert_id, 'approach' ) as $item ) : ?>
								<li>
									<?php echo ptl_icon( 'badge-check', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									<?php echo esc_html( $item ); ?>
								</li>
							<?php endforeach; ?>
						</ul>
					</section>

					<section class="prose-block">
						<h2>Modalities</h2>
						<div class="chip-row">
							<?php foreach ( ptl_lines( $expert_id, 'modalities' ) as $item ) : ?>
								<span class="chip chip--static"><?php echo esc_html( $item ); ?></span>
							<?php endforeach; ?>
						</div>
					</section>

					<section class="prose-block">
						<h2>Credentials &amp; verification</h2>
						<p><?php echo esc_html( ptl_meta( $expert_id, 'credential' ) ); ?></p>
						<div class="verification-note">
							<?php echo ptl_icon( 'shield-check', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<p>
								In the live directory, registration numbers are checked against the
								relevant council before a profile is published. Peer supporters are
								labelled as non-clinical and do not diagnose.
							</p>
						</div>
					</section>

					<section class="prose-block">
						<h2>Circles with <?php echo esc_html( $first ); ?></h2>
						<?php if ( $hosted ) : ?>
							<ul class="hosted-list">
								<?php foreach ( $hosted as $event ) : ?>
									<li>
										<div>
											<span class="hosted-kind"><?php echo esc_html( ptl_meta( $event->ID, 'kind' ) ); ?></span>
											<a href="<?php echo esc_url( get_permalink( $event ) ); ?>"><?php echo esc_html( get_the_title( $event ) ); ?></a>
										</div>
										<span class="hosted-date"><?php echo esc_html( ptl_format_short_date( ptl_meta( $event->ID, 'start' ) ) ); ?></span>
									</li>
								<?php endforeach; ?>
							</ul>
						<?php else : ?>
							<p>No circles scheduled right now. Ask the team to let you know when one is.</p>
						<?php endif; ?>
					</section>
				</div>

				<aside class="expert-profile-aside">
					<div class="connect-card">
						<p class="eyebrow">Next step</p>
						<h2>Ask to connect</h2>
						<p>
							Tell us what you're looking for. The team will read it and, if it feels
							like a fit, explain how to reach <?php echo esc_html( $first ); ?> directly.
						</p>
						<a href="<?php echo esc_url( ptl_page_url( 'ask' ) . '?path=support&practitioner=' . get_post_field( 'post_name', $expert_id ) ); ?>" class="btn btn-primary btn-block">
							Start a private ask
							<?php echo ptl_icon( 'arrow-up-right', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</a>
						<p class="form-note">No account needed. You can leave your name blank.</p>
					</div>

					<div class="aside-note">
						<strong>Not sure who to pick?</strong>
						<p>
							<a href="<?php echo esc_url( ptl_page_url( 'ask' ) ); ?>">Ask the team</a> — describe what's going on and we'll suggest a starting point.
						</p>
					</div>
				</aside>
			</div>
		</div>

		<section class="section section--tint">
			<div class="container">
				<?php
				ptl_section_head(
					'Keep looking',
					'Other people in the directory',
					'',
					ptl_archive_url( 'expert' ),
					'See everyone'
				);
				?>
				<div class="expert-grid">
					<?php foreach ( $others as $expert ) : ?>
						<?php ptl_expert_card( $expert ); ?>
					<?php endforeach; ?>
				</div>
			</div>
		</section>
	</div>
	<?php
endwhile;

get_footer();
