<?php
/**
 * Front page.
 *
 * @package PuchTohLo
 */

get_header();

$events      = ptl_get_events( 'ASC' );
$upcoming    = array_values(
	array_filter(
		$events,
		function ( $event ) {
			return ! ptl_is_past( ptl_meta( $event->ID, 'start' ) );
		}
	)
);
$next_event  = isset( $upcoming[0] ) ? $upcoming[0] : null;
$experts     = ptl_get_experts();
$featured    = array_values(
	array_filter(
		$experts,
		function ( $expert ) {
			return ptl_flag( $expert->ID, 'featured' );
		}
	)
);
if ( ! $featured ) {
	$featured = array_slice( $experts, 0, 3 );
}
$conversations = ptl_get_conversations();
$lead_content  = isset( $conversations[0] ) ? $conversations[0] : null;
$more_content  = array_slice( $conversations, 1, 3 );
$image_base    = get_template_directory_uri() . '/assets/images/';
?>

<section class="hero">
	<div class="container hero-grid">
		<div class="hero-copy">
			<p class="eyebrow hero-eyebrow">
				<span class="eyebrow-dot" aria-hidden="true"></span>
				Pune · online everywhere
			</p>
			<h1 class="display hero-title">
				Some questions need a <span class="accent-word">room</span>, not a
				search bar.
			</h1>
			<p class="lede hero-lede">
				Puch Toh Lo is a space to ask what you're actually carrying — loneliness,
				relationships, motherhood, burnout, being human. Find a practitioner,
				join a circle, or start by listening.
			</p>
			<div class="hero-actions">
				<a href="<?php echo esc_url( ptl_page_url( 'ask' ) ); ?>" class="btn btn-primary">
					Ask something
					<?php echo ptl_icon( 'arrow-up-right', 17 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</a>
				<a href="<?php echo esc_url( ptl_archive_url( 'event' ) ); ?>" class="btn btn-outline">
					See what's on
				</a>
			</div>
			<ul class="proof-list">
				<li><?php echo ptl_icon( 'check', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> No account needed to ask</li>
				<li><?php echo ptl_icon( 'check', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> Online circles and Pune meetups</li>
				<li><?php echo ptl_icon( 'check', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> One directory across kinds of help</li>
			</ul>
		</div>

		<div class="hero-art">
			<div class="hero-frame">
				<img src="<?php echo esc_url( $image_base . 'hero-room.jpg' ); ?>" alt="A warm, sunlit room with a linen armchair, plants and a cup of chai">
				<span class="hero-seal" aria-hidden="true">Ask · Listen · Belong</span>
			</div>

			<?php if ( $next_event ) : ?>
				<div class="hero-note hero-note--next">
					<span class="note-kicker">Next circle</span>
					<?php
					$title_parts = explode( ':', get_the_title( $next_event ) );
					$start       = ptl_meta( $next_event->ID, 'start' );
					?>
					<strong><?php echo esc_html( trim( $title_parts[0] ) ); ?></strong>
					<span class="note-meta">
						<?php echo esc_html( ptl_format_short_date( $start ) ); ?> · <?php echo esc_html( ptl_format_time( $start ) ); ?>
					</span>
					<a href="<?php echo esc_url( get_permalink( $next_event ) ); ?>" class="note-link">
						Reserve a spot
						<?php echo ptl_icon( 'arrow-up-right', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</a>
				</div>
			<?php endif; ?>

			<div class="hero-note hero-note--quote">
				<span class="note-quote" aria-hidden="true">“</span>
				<p>You don't have to explain it perfectly.</p>
			</div>
		</div>
	</div>
</section>

<div class="marquee-band" aria-hidden="true">
	<div class="marquee-track">
		<?php for ( $copy = 0; $copy < 2; $copy++ ) : ?>
			<div class="marquee-group">
				<span>Therapy</span><span>·</span>
				<span>Circles</span><span>·</span>
				<span>Community</span><span>·</span>
				<span>Conversations</span><span>·</span>
				<span>Mom Circle</span><span>·</span>
				<span>Ask anything</span><span>·</span>
			</div>
		<?php endfor; ?>
	</div>
</div>

<section class="section">
	<div class="container">
		<?php
		ptl_section_head(
			'Start where you are',
			'Three ways in. No right order.',
			"You don't need a diagnosis, a clear question or a plan. Start with the door that feels least heavy."
		);
		?>
		<div class="path-grid">
			<a href="<?php echo esc_url( ptl_page_url( 'ask' ) ); ?>" class="path-card">
				<span class="path-number">01</span>
				<span class="path-icon"><?php echo ptl_icon( 'message-circle', 22 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<h3>Ask a question</h3>
				<p>Tell us what's going on. We'll point you to the right kind of support — or just listen, if that's what you need.</p>
				<span class="path-link">
					Start with a question
					<?php echo ptl_icon( 'arrow-right', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</span>
			</a>

			<a href="<?php echo esc_url( ptl_archive_url( 'event' ) ); ?>" class="path-card">
				<span class="path-number">02</span>
				<span class="path-icon"><?php echo ptl_icon( 'users', 22 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<h3>Join a circle</h3>
				<p>Small, hosted spaces for mothers, couples and anyone tired of holding it alone. Online and in Pune, small on purpose.</p>
				<span class="path-link">
					See upcoming circles
					<?php echo ptl_icon( 'arrow-right', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</span>
			</a>

			<a href="<?php echo esc_url( ptl_archive_url( 'expert' ) ); ?>" class="path-card">
				<span class="path-number">03</span>
				<span class="path-icon"><?php echo ptl_icon( 'heart-handshake', 22 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<h3>Find a practitioner</h3>
				<p>One directory of therapists, coaches, facilitators and peer supporters. Filter by what you need, not by what you're called.</p>
				<span class="path-link">
					Browse the directory
					<?php echo ptl_icon( 'arrow-right', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</span>
			</a>
		</div>
	</div>
</section>

<section class="section section--tint">
	<div class="container">
		<?php
		ptl_section_head(
			'Coming up',
			'A place at the table',
			'Small, hosted, and gently structured. No performance required.',
			ptl_archive_url( 'event' ),
			'All circles & events'
		);
		?>
		<div class="event-list">
			<?php foreach ( array_slice( $upcoming, 0, 3 ) as $event ) : ?>
				<?php ptl_event_card( $event, true ); ?>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="section">
	<div class="container">
		<?php
		ptl_section_head(
			'The conversations',
			'Listen first. Then maybe ask.',
			'Podcast episodes, Expert Bytes, Mom Circle reflections and posts — collected in one place.',
			ptl_archive_url( 'conversation' ),
			'Browse the archive'
		);
		?>
		<div class="home-content-grid">
			<?php if ( $lead_content ) : ?>
				<?php ptl_content_card( $lead_content, true ); ?>
			<?php endif; ?>
			<div class="home-content-aside">
				<?php foreach ( $more_content as $item ) : ?>
					<?php ptl_content_card( $item, false, false ); ?>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</section>

<section class="section section--tint">
	<div class="container">
		<?php
		ptl_section_head(
			'The directory',
			'Real people, not algorithms',
			'Therapists, coaches, facilitators and peer supporters. Credentials are checked where they apply.',
			ptl_archive_url( 'expert' ),
			'Meet everyone'
		);
		?>
		<div class="expert-grid">
			<?php foreach ( $featured as $expert ) : ?>
				<?php ptl_expert_card( $expert ); ?>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="section">
	<div class="container">
		<div class="about-band">
			<div class="about-band-media">
				<img src="<?php echo esc_url( $image_base . 'circle.jpg' ); ?>" alt="A circle of women sitting together with chai in a sunlit home" loading="lazy">
				<span class="about-media-caption">Mom Circle · Pune</span>
			</div>
			<div class="about-band-copy">
				<p class="eyebrow">The idea</p>
				<h2 class="h2">Ask first. Advice later.</h2>
				<p>
					Most of us wait until something is unbearable before we ask for help.
					Puch Toh Lo is an attempt to make the asking earlier, smaller and less
					lonely.
				</p>
				<p>
					It began as The Healing Room, a space for conversations about mental
					health that felt too clinical for a clinic and too personal for a
					search engine. The name changed. The invitation didn't.
				</p>
				<div class="about-band-actions">
					<a href="<?php echo esc_url( ptl_page_url( 'about' ) ); ?>" class="text-link">
						Read the longer story
						<?php echo ptl_icon( 'arrow-up-right', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</a>
					<a href="<?php echo esc_url( ptl_page_url( 'ask' ) ); ?>" class="text-link">
						Ask us anything
						<?php echo ptl_icon( 'arrow-up-right', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</a>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="cta-band">
	<div class="container cta-band-inner">
		<p class="eyebrow">No perfect words needed</p>
		<h2 class="display cta-title">What's one thing you've been meaning to ask?</h2>
		<p class="cta-lede">
			Start with a sentence. A typo. A feeling you can't name yet. A real person
			from the team will read it.
		</p>
		<div class="cta-actions">
			<a href="<?php echo esc_url( ptl_page_url( 'ask' ) ); ?>" class="btn btn-primary">
				Ask something
				<?php echo ptl_icon( 'arrow-up-right', 17 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</a>
			<a href="<?php echo esc_url( ptl_archive_url( 'event' ) ); ?>" class="btn btn-outline">
				Find a circle
			</a>
		</div>
	</div>
</section>

<?php
get_footer();
