<?php
/**
 * Circles & events archive.
 *
 * @package PuchTohLo
 */

get_header();

$events = ptl_get_events( 'ASC' );
$past   = array();
$next   = array();

foreach ( $events as $event ) {
	if ( ptl_is_past( ptl_meta( $event->ID, 'start' ) ) ) {
		$past[] = $event;
	} else {
		$next[] = $event;
	}
}
$past = array_reverse( $past );

$aside = '<div class="page-head-stat"><strong>' . esc_html( count( $next ) ) . '</strong><span>circles coming up</span><span class="page-head-stat-note">Online &amp; in Pune</span></div>';

ptl_page_head(
	'Circles & events',
	"Small rooms.<br>Real conversation.",
	'Hosted circles, listening spaces and meetups for the things that are hard to say out loud. Small on purpose, no performance required.',
	$aside
);
?>

<div class="container">
	<div class="events-toolbar">
		<div class="segmented" role="tablist" aria-label="Event timeframe" data-event-tabs>
			<button role="tab" aria-selected="true" class="segment is-active" data-event-tab="upcoming">
				Upcoming
				<span><?php echo esc_html( count( $next ) ); ?></span>
			</button>
			<button role="tab" aria-selected="false" class="segment" data-event-tab="past">
				Past
				<span><?php echo esc_html( count( $past ) ); ?></span>
			</button>
		</div>
		<p class="toolbar-note">
			<?php echo ptl_icon( 'calendar-plus', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			RSVP takes under a minute. Calendar invite included.
		</p>
	</div>

	<div class="event-list event-list--page" data-event-panel="upcoming">
		<?php foreach ( $next as $event ) : ?>
			<?php ptl_event_card( $event ); ?>
		<?php endforeach; ?>
		<?php if ( ! $next ) : ?>
			<?php ptl_empty_state( 'No circles scheduled', 'New dates are added regularly. Join the WhatsApp circle or ask us to let you know.' ); ?>
		<?php endif; ?>
	</div>

	<div class="event-list event-list--page" data-event-panel="past" hidden>
		<?php foreach ( $past as $event ) : ?>
			<?php ptl_event_card( $event ); ?>
		<?php endforeach; ?>
		<?php if ( ! $past ) : ?>
			<?php ptl_empty_state( 'Nothing in the archive yet', 'Past circles will be collected here.' ); ?>
		<?php endif; ?>
	</div>

	<div class="events-help-grid">
		<article class="info-card">
			<span class="info-icon"><?php echo ptl_icon( 'video', 19 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			<h3>Online circles</h3>
			<p>
				Join from wherever you are. Cameras can stay off and you can pass on any
				round. The link arrives by email after you RSVP.
			</p>
		</article>
		<article class="info-card">
			<span class="info-icon"><?php echo ptl_icon( 'message-circle', 19 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			<h3>What happens after you RSVP</h3>
			<p>
				A confirmation, a calendar invite, and one gentle reminder. No group chat
				added without asking. You can cancel any time.
			</p>
		</article>
		<article class="info-card info-card--tint">
			<span class="info-icon"><?php echo ptl_icon( 'arrow-up-right', 19 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			<h3>Want a reminder?</h3>
			<p>
				Join the WhatsApp circle for event notes and the occasional voice message
				from the team.
			</p>
			<a href="<?php echo esc_url( ptl_page_url( 'ask' ) . '?path=community' ); ?>" class="text-link">
				Join the circle
				<?php echo ptl_icon( 'arrow-up-right', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</a>
		</article>
	</div>

	<p class="feed-note">
		<strong>Demo note:</strong> these are sample listings for design review. Dates,
		hosts and capacity are placeholders and editable in WordPress.
	</p>
</div>

<?php
get_footer();
