<?php
/**
 * Site header.
 *
 * @package PuchTohLo
 */
?><!doctype html>
<html <?php language_attributes(); ?> data-design="calm">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<?php wp_head(); ?>
</head>
<body <?php body_class( 'ptl-body' ); ?>>
<?php wp_body_open(); ?>
<div class="site">
	<a class="skip-link" href="#main">Skip to content</a>

	<header class="site-header" data-site-header>
		<div class="container header-inner">
			<?php ptl_logo(); ?>

			<nav class="desktop-nav" aria-label="Main">
				<?php foreach ( ptl_nav_items() as $item ) : ?>
					<a href="<?php echo esc_url( $item['url'] ); ?>" class="nav-link <?php echo ptl_nav_active( $item['key'] ) ? 'is-active' : ''; ?>" <?php echo ptl_nav_active( $item['key'] ) ? 'aria-current="page"' : ''; ?>>
						<?php echo esc_html( $item['label'] ); ?>
					</a>
				<?php endforeach; ?>
			</nav>

			<div class="header-actions">
				<a href="<?php echo esc_url( ptl_page_url( 'ask' ) ); ?>" class="btn btn-primary btn-sm header-cta">
					Ask something
					<?php echo ptl_icon( 'arrow-up-right', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</a>
				<button type="button" class="menu-toggle" aria-expanded="false" aria-controls="mobile-nav" aria-label="Open menu" data-menu-toggle>
					<span data-menu-open-icon><?php echo ptl_icon( 'menu', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<span data-menu-close-icon hidden><?php echo ptl_icon( 'x', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				</button>
			</div>
		</div>

		<div id="mobile-nav" class="mobile-panel" hidden>
			<nav class="mobile-nav" aria-label="Mobile">
				<?php foreach ( ptl_nav_items() as $index => $item ) : ?>
					<a href="<?php echo esc_url( $item['url'] ); ?>" class="mobile-link <?php echo ptl_nav_active( $item['key'] ) ? 'is-active' : ''; ?>">
						<span class="mobile-index">0<?php echo esc_html( $index + 1 ); ?></span>
						<?php echo esc_html( $item['label'] ); ?>
						<?php echo ptl_icon( 'arrow-up-right', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</a>
				<?php endforeach; ?>
				<a href="<?php echo esc_url( ptl_page_url( 'ask' ) ); ?>" class="btn btn-primary mobile-ask">
					Ask something
					<?php echo ptl_icon( 'arrow-up-right', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</a>
				<div class="mobile-foot">
					<p>Ask. Listen. Belong.</p>
					<?php ptl_social_links(); ?>
				</div>
			</nav>
		</div>
	</header>

	<main id="main" tabindex="-1">
