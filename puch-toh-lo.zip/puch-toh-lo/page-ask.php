<?php
/**
 * Ask page: support, community and practitioner doors.
 *
 * @package PuchTohLo
 */

get_header();

$languages  = array( 'English', 'Hindi', 'Marathi', 'Urdu', 'Malayalam', 'Tamil', 'Bengali', 'Other' );
$roles      = array( 'Clinical psychologist', 'Counselling psychologist', 'Psychotherapist', 'Couples & family therapist', 'Coach', 'Expressive arts facilitator', 'Nutritionist', 'Peer supporter' );
$modalities = array( 'CBT', 'ACT', 'Psychodynamic', 'Narrative therapy', 'Emotionally focused therapy', 'Somatic work', 'Expressive arts', 'Intuitive eating', 'Coaching', 'Peer support', 'Group facilitation' );

$expert_slug = isset( $_GET['practitioner'] ) ? sanitize_title( wp_unslash( $_GET['practitioner'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$expert      = $expert_slug ? ptl_expert_by_slug( $expert_slug ) : null;
$path        = isset( $_GET['path'] ) ? sanitize_key( wp_unslash( $_GET['path'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
if ( ! in_array( $path, array( 'support', 'community', 'practitioner' ), true ) ) {
	$path = $expert ? 'support' : '';
}

ptl_page_head(
	'The ask',
	"Say it here.<br>We'll take it from there.",
	'One door for support, community or joining as a practitioner. No account, no perfect words, no automated quiz.'
);
?>

<section class="ask-page">
	<div class="container">
		<div class="ask-shell" data-ask-shell data-initial-path="<?php echo esc_attr( $path ); ?>">
			<div class="ask-main">
				<div class="ask-progress" aria-label="Progress" data-ask-progress>
					<span class="ask-step <?php echo $path ? 'is-done' : ''; ?>" data-step="1"><span>1</span> Choose a door</span>
					<span class="ask-step-line" aria-hidden="true"></span>
					<span class="ask-step" data-step="2"><span>2</span> Tell us a little</span>
					<span class="ask-step-line" aria-hidden="true"></span>
					<span class="ask-step" data-step="3"><span>3</span> We reply</span>
				</div>

				<div class="intent-grid" data-intent-grid <?php echo $path ? 'hidden' : ''; ?>>
					<button type="button" class="intent-card" data-intent="support">
						<span class="intent-index">01</span>
						<span class="intent-icon"><?php echo ptl_icon( 'heart-handshake', 23 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
						<span class="intent-title">I need support</span>
						<span class="intent-body">Something is heavy. Tell us what's going on and we'll help you find the next step — a practitioner, a circle, or just a reply.</span>
						<span class="intent-note">Private. Your name is optional.</span>
						<span class="intent-cta">Ask for support <?php echo ptl_icon( 'arrow-right', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					</button>

					<button type="button" class="intent-card" data-intent="community">
						<span class="intent-index">02</span>
						<span class="intent-icon"><?php echo ptl_icon( 'users', 23 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
						<span class="intent-title">I want to join the community</span>
						<span class="intent-body">Circles, event notes and the WhatsApp group. Start with a short introduction so we can send the right invite.</span>
						<span class="intent-note">WhatsApp number required.</span>
						<span class="intent-cta">Request to join <?php echo ptl_icon( 'arrow-right', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					</button>

					<button type="button" class="intent-card" data-intent="practitioner">
						<span class="intent-index">03</span>
						<span class="intent-icon"><?php echo ptl_icon( 'briefcase', 23 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
						<span class="intent-title">I'm a practitioner</span>
						<span class="intent-body">Therapists, coaches, facilitators, nutritionists and peer supporters. Share your modalities, languages and how you work.</span>
						<span class="intent-note">Reviewed by a human.</span>
						<span class="intent-cta">Apply to the directory <?php echo ptl_icon( 'arrow-right', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					</button>
				</div>

				<div class="ask-form-card" data-ask-form hidden>
					<div class="ask-form-head">
						<button type="button" class="back-link" data-ask-back>
							<?php echo ptl_icon( 'arrow-left', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							Choose another door
						</button>
						<p class="eyebrow" data-ask-eyebrow>Private ask</p>
						<h2 class="ask-form-title" data-ask-title>Tell us what's going on.</h2>
						<p class="ask-form-intro" data-ask-intro>You don't have to explain it perfectly. A real person on the team will read this.</p>
					</div>

					<?php if ( $expert ) : ?>
						<div class="expert-context" data-expert-context>
							<div class="expert-context-media">
								<?php $expert_photo = ptl_image_url( $expert->ID, 'photo' ); ?>
								<?php if ( $expert_photo ) : ?>
									<img src="<?php echo esc_url( $expert_photo ); ?>" alt="">
								<?php else : ?>
									<span style="background-color: <?php echo esc_attr( ptl_meta( $expert->ID, 'tone', '#8a6a55' ) ); ?>" aria-hidden="true"><?php echo esc_html( ptl_meta( $expert->ID, 'initials', 'PT' ) ); ?></span>
								<?php endif; ?>
							</div>
							<div>
								<span class="sample-badge">Sample profile</span>
								<strong><?php echo esc_html( get_the_title( $expert ) ); ?></strong>
								<span><?php echo esc_html( ptl_meta( $expert->ID, 'role' ) ); ?> · <?php echo esc_html( ptl_meta( $expert->ID, 'mode' ) ); ?></span>
							</div>
							<a href="<?php echo esc_url( ptl_archive_url( 'expert' ) ); ?>" class="text-link">Change</a>
						</div>
					<?php endif; ?>

					<!-- Support -->
					<div data-ask-panel="support" hidden>
						<form class="ask-form" data-ask-form-el="support" novalidate>
							<div class="field">
								<label for="support-message">What's on your mind?</label>
								<textarea id="support-message" class="input textarea textarea--lg" rows="6" placeholder="Start anywhere. A feeling, a situation, a sentence you can't say out loud." required minlength="10" data-min-length="10"></textarea>
								<p class="field-error" data-error-for="message" hidden>A sentence or two is enough — just tell us what's going on.</p>
							</div>

							<div class="field">
								<label for="support-name">Your name <span class="label-note">optional</span></label>
								<input id="support-name" class="input" autocomplete="name" placeholder="Leave blank if you'd rather not">
							</div>

							<div class="field-grid">
								<div class="field">
									<label for="support-email">Email</label>
									<input id="support-email" class="input" type="email" autocomplete="email">
								</div>
								<div class="field">
									<label for="support-whatsapp">WhatsApp</label>
									<input id="support-whatsapp" class="input" type="tel" autocomplete="tel">
								</div>
							</div>
							<p class="field-hint">Leave at least one. We reply on whichever feels easier for you.</p>
							<p class="field-error" data-error-for="contact" hidden>Leave an email or WhatsApp number so we can reply.</p>

							<div class="field-grid">
								<div class="field">
									<label for="support-language">Preferred language</label>
									<select id="support-language" class="input select">
										<?php foreach ( $languages as $language ) : ?>
											<option><?php echo esc_html( $language ); ?></option>
										<?php endforeach; ?>
									</select>
								</div>
								<div class="field">
									<label for="support-need">What would help most?</label>
									<select id="support-need" class="input select" <?php echo $expert ? 'disabled' : ''; ?>>
										<option>A listening reply</option>
										<option <?php echo $expert ? 'selected' : ''; ?>>A practitioner referral</option>
										<option>A circle or community</option>
										<option>Not sure yet</option>
									</select>
								</div>
							</div>

							<label class="check-row">
								<input type="checkbox" required>
								<span>I agree to be contacted by the Puch Toh Lo team about this ask.</span>
							</label>
							<p class="field-error" data-error-for="consent" hidden>Please agree to be contacted so we can reply.</p>

							<div class="form-actions">
								<button type="submit" class="btn btn-primary">
									Send my ask
									<?php echo ptl_icon( 'arrow-up-right', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								</button>
								<span class="form-note"><?php echo ptl_icon( 'lock', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> Demo form: nothing is sent or stored.</span>
							</div>
						</form>
					</div>

					<!-- Community -->
					<div data-ask-panel="community" hidden>
						<form class="ask-form" data-ask-form-el="community" novalidate>
							<div class="field-grid">
								<div class="field">
									<label for="community-name">Your name</label>
									<input id="community-name" class="input" autocomplete="name" required>
								</div>
								<div class="field">
									<label for="community-whatsapp">WhatsApp number</label>
									<input id="community-whatsapp" class="input" type="tel" autocomplete="tel" required>
								</div>
							</div>

							<div class="field-grid">
								<div class="field">
									<label for="community-email">Email <span class="label-note">optional</span></label>
									<input id="community-email" class="input" type="email" autocomplete="email">
								</div>
								<div class="field">
									<label for="community-city">City <span class="label-note">optional</span></label>
									<input id="community-city" class="input" autocomplete="address-level2">
								</div>
							</div>

							<div class="field">
								<label for="community-message">What are you hoping to find? <span class="label-note">optional</span></label>
								<textarea id="community-message" class="input textarea" rows="4" placeholder="A circle in Pune, the WhatsApp group, or just to listen for a while."></textarea>
							</div>

							<div class="field">
								<label for="community-language">Preferred language</label>
								<select id="community-language" class="input select">
									<?php foreach ( $languages as $language ) : ?>
										<option><?php echo esc_html( $language ); ?></option>
									<?php endforeach; ?>
								</select>
							</div>

							<label class="check-row">
								<input type="checkbox" required>
								<span>I agree to be contacted about circles and the community. I understand the WhatsApp group is optional.</span>
							</label>

							<div class="form-actions">
								<button type="submit" class="btn btn-primary">
									Request to join
									<?php echo ptl_icon( 'arrow-up-right', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								</button>
								<span class="form-note"><?php echo ptl_icon( 'lock', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> Demo form: nothing is sent or stored.</span>
							</div>
						</form>
					</div>

					<!-- Practitioner -->
					<div data-ask-panel="practitioner" hidden>
						<form class="ask-form" data-ask-form-el="practitioner" novalidate>
							<div class="field-grid">
								<div class="field">
									<label for="practice-name">Full name</label>
									<input id="practice-name" class="input" autocomplete="name" required>
								</div>
								<div class="field">
									<label for="practice-email">Email</label>
									<input id="practice-email" class="input" type="email" autocomplete="email" required>
								</div>
							</div>

							<div class="field-grid">
								<div class="field">
									<label for="practice-phone">Phone / WhatsApp <span class="label-note">optional</span></label>
									<input id="practice-phone" class="input" type="tel" autocomplete="tel">
								</div>
								<div class="field">
									<label for="practice-role">Your role</label>
									<select id="practice-role" class="input select" required>
										<option value="">Select a role</option>
										<?php foreach ( $roles as $role ) : ?>
											<option><?php echo esc_html( $role ); ?></option>
										<?php endforeach; ?>
									</select>
								</div>
							</div>

							<div class="field">
								<label>Modalities</label>
								<div class="chip-picker" role="group" aria-label="Modalities" data-chip-group="modalities">
									<?php foreach ( $modalities as $modality ) : ?>
										<button type="button" class="chip" aria-pressed="false"><?php echo esc_html( $modality ); ?></button>
									<?php endforeach; ?>
								</div>
								<p class="field-error" data-error-for="modalities" hidden>Pick at least one modality.</p>
							</div>

							<div class="field">
								<label>Languages you work in</label>
								<div class="chip-picker" role="group" aria-label="Languages" data-chip-group="languages">
									<?php foreach ( $languages as $language ) : ?>
										<button type="button" class="chip <?php echo 'English' === $language ? 'is-selected' : ''; ?>" aria-pressed="<?php echo 'English' === $language ? 'true' : 'false'; ?>"><?php echo esc_html( $language ); ?></button>
									<?php endforeach; ?>
								</div>
								<p class="field-error" data-error-for="languages" hidden>Pick at least one language.</p>
							</div>

							<div class="field-grid">
								<div class="field">
									<label for="practice-mode">Sessions</label>
									<select id="practice-mode" class="input select">
										<option>Online</option>
										<option>In person</option>
										<option>Online &amp; in person</option>
									</select>
								</div>
								<div class="field">
									<label for="practice-fee">Fee range <span class="label-note">optional</span></label>
									<input id="practice-fee" class="input" placeholder="e.g. ₹1,200 / session">
								</div>
							</div>

							<div class="field">
								<label for="practice-credential">Credentials &amp; registration <span class="label-note">optional</span></label>
								<input id="practice-credential" class="input" placeholder="Degree, council registration, training">
							</div>

							<div class="field">
								<label for="practice-bio">How you work</label>
								<textarea id="practice-bio" class="input textarea textarea--lg" rows="5" placeholder="Who do you work with? What does a session feel like? What do you not do?" required minlength="40" data-min-length="40"></textarea>
								<p class="field-error" data-error-for="bio" hidden>A few sentences about how you work is enough.</p>
							</div>

							<div class="field">
								<label for="practice-link">Website or profile <span class="label-note">optional</span></label>
								<input id="practice-link" class="input" placeholder="https://">
							</div>

							<label class="check-row">
								<input type="checkbox" required>
								<span>I confirm this information is accurate and agree to the team checking credentials where they apply.</span>
							</label>

							<div class="form-actions">
								<button type="submit" class="btn btn-primary">
									Submit application
									<?php echo ptl_icon( 'arrow-up-right', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								</button>
								<span class="form-note"><?php echo ptl_icon( 'lock', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> Demo form: nothing is sent or stored.</span>
							</div>
						</form>
					</div>
				</div>

				<div class="ask-success" data-ask-success hidden>
					<span class="success-icon" aria-hidden="true"><?php echo ptl_icon( 'check-circle', 30 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<p class="eyebrow">Received</p>
					<h2 class="ask-form-title" data-success-title>Your ask is here.</h2>
					<p class="ask-form-intro" data-success-copy>
						In the live portal, a real person from the team would read this and reply.
						Nothing has been sent in this demo.
					</p>

					<div class="whatsapp-callout" data-success-whatsapp hidden>
						<div>
							<strong>Open the WhatsApp group</strong>
							<p>Group members can see your number. You can leave at any time.</p>
						</div>
						<a class="btn btn-primary" href="https://chat.whatsapp.com/EAdWgNU40M01yrV7kDH9pv" target="_blank" rel="noreferrer">
							Open WhatsApp
							<?php echo ptl_icon( 'external-link', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</a>
					</div>

					<div class="next-steps">
						<h3>What happens next</h3>
						<ol data-success-steps="support" hidden>
							<li>A person on the team reads it — not a bot.</li>
							<li>We reply on the contact you left, gently and privately.</li>
							<li>If you want, we suggest a practitioner, a circle or another next step.</li>
						</ol>
						<ol data-success-steps="community" hidden>
							<li>The team reads your introduction.</li>
							<li>We send the current invite and what to expect.</li>
							<li>You decide whether the group is right for you.</li>
						</ol>
						<ol data-success-steps="practitioner" hidden>
							<li>The team reads your modalities and how you work.</li>
							<li>We check credentials where they apply.</li>
							<li>We reply by email with next steps or a clear no.</li>
						</ol>
					</div>

					<div class="success-meta">
						<span>Reference</span>
						<code data-success-reference>PTL-0000</code>
						<span class="sample-badge">Demo only</span>
					</div>

					<div class="success-actions">
						<button type="button" class="btn btn-primary" data-ask-restart>
							Ask something else
						</button>
						<a href="<?php echo esc_url( ptl_archive_url( 'event' ) ); ?>" class="btn btn-outline">See circles</a>
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="text-link">Back to home</a>
					</div>

					<div data-success-crisis hidden>
						<?php ptl_crisis_note(); ?>
					</div>
				</div>
			</div>

			<aside class="ask-aside">
				<div class="ask-side-card">
					<p class="eyebrow">What happens here</p>
					<h3>Read by a person. Not a quiz.</h3>
					<ol class="side-steps">
						<li><span>01</span><p>You choose the door that feels closest.</p></li>
						<li><span>02</span><p>You share as much or as little as you want.</p></li>
						<li><span>03</span><p>The team replies and suggests a next step.</p></li>
					</ol>
					<p class="form-note">This WordPress demo does not send or store form entries. In the live portal, a person reads every request.</p>
				</div>

				<?php ptl_crisis_note(); ?>

				<div class="aside-note">
					<strong>Prefer not to write?</strong>
					<p>
						You can also <a href="https://www.instagram.com/puchtohlo/" target="_blank" rel="noreferrer">send a DM on Instagram</a>
						or come to a circle and just listen.
					</p>
				</div>
			</aside>
		</div>
	</div>
</section>

<?php
get_footer();
