<?php
/**
 * Site footer.
 *
 * @package PuchTohLo
 */
?>
	</main>

	<footer class="site-footer">
		<div class="container footer-grid">
			<div class="footer-brand">
				<?php ptl_logo(); ?>
				<p class="footer-blurb">
					A quieter corner of the internet for honest questions about feelings,
					relationships and everyday mental health.
				</p>
				<?php ptl_social_links(); ?>
			</div>

			<div class="footer-col">
				<h3>Explore</h3>
				<ul>
					<li><a href="<?php echo esc_url( ptl_archive_url( 'conversation' ) ); ?>">Conversations</a></li>
					<li><a href="<?php echo esc_url( ptl_archive_url( 'event' ) ); ?>">Circles &amp; events</a></li>
					<li><a href="<?php echo esc_url( ptl_archive_url( 'expert' ) ); ?>">The directory</a></li>
					<li><a href="<?php echo esc_url( ptl_page_url( 'about' ) ); ?>">About Puch Toh Lo</a></li>
				</ul>
			</div>

			<div class="footer-col">
				<h3>Community</h3>
				<ul>
					<li><a href="<?php echo esc_url( ptl_page_url( 'ask' ) ); ?>">Ask a question</a></li>
					<li><a href="<?php echo esc_url( ptl_page_url( 'ask' ) . '?path=community' ); ?>">Join the WhatsApp circle</a></li>
					<li><a href="<?php echo esc_url( ptl_page_url( 'ask' ) . '?path=practitioner' ); ?>">Join as a practitioner</a></li>
					<li><a href="<?php echo esc_url( ptl_archive_url( 'event' ) ); ?>">Come to a circle</a></li>
				</ul>
			</div>

			<div class="footer-col footer-help">
				<h3>If today is hard</h3>
				<p>
					Tele-MANAS <a href="tel:14416">14416</a> — free, 24×7 support.
					<br>
					Emergency: <a href="tel:112">112</a>.
				</p>
				<p class="footer-small">This portal is not an emergency service.</p>
			</div>
		</div>

		<div class="container footer-bottom">
			<p>© 2026 Puch Toh Lo · formerly The Healing Room</p>
			<p class="prototype-note">
				WordPress demo · sample content · forms are presentation-only
			</p>
			<?php if ( current_user_can( 'edit_posts' ) ) : ?>
				<a href="<?php echo esc_url( admin_url( 'edit.php?post_type=expert' ) ); ?>" class="footer-admin">Edit content</a>
			<?php else : ?>
				<a href="<?php echo esc_url( wp_login_url() ); ?>" class="footer-admin">Admin</a>
			<?php endif; ?>
		</div>
	</footer>

	<?php ptl_design_dock(); ?>
</div>
<?php wp_footer(); ?>
</body>
</html>
