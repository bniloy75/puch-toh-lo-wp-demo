<?php
/**
 * Generic page.
 *
 * @package PuchTohLo
 */

get_header();

while ( have_posts() ) :
	the_post();
	?>
	<section class="section">
		<div class="container narrow">
			<p class="eyebrow">Puch Toh Lo</p>
			<h1 class="page-title"><?php the_title(); ?></h1>
			<div class="prose-block">
				<?php the_content(); ?>
			</div>
		</div>
	</section>
	<?php
endwhile;

get_footer();
