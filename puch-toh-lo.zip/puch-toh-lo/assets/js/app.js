(function () {
  "use strict";

  var root = document.documentElement;
  var DESIGN_KEY = "ptl.design.v1";
  var DESIGN_COLORS = { calm: "#f5efe4", modern: "#fbfaf6", bold: "#0f1f19" };

  /* ------------------------------------------------------------
     Design dock
     ------------------------------------------------------------ */
  function syncDesign(design) {
    root.dataset.design = design;

    document.querySelectorAll("[data-design-option]").forEach(function (button) {
      var active = button.getAttribute("data-design-option") === design;
      button.classList.toggle("is-active", active);
      if (button.getAttribute("role") === "radio") {
        button.setAttribute("aria-checked", active ? "true" : "false");
      }
      var note = button.closest(".design-note");
      if (note) {
        note.classList.toggle("is-active", active);
      }
    });

    var meta = document.querySelector('meta[name="theme-color"]');
    if (meta && DESIGN_COLORS[design]) {
      meta.setAttribute("content", DESIGN_COLORS[design]);
    }
  }

  function setDesign(design) {
    if (!DESIGN_COLORS[design]) return;
    syncDesign(design);
    try {
      window.localStorage.setItem(DESIGN_KEY, design);
    } catch (error) {}
  }

  var dock = document.querySelector("[data-design-dock]");
  if (dock) {
    var notes = dock.querySelector(".design-notes");
    var info = dock.querySelector("[data-design-info]");
    var close = dock.querySelector("[data-design-close]");

    function setNotes(open) {
      if (!notes) return;
      notes.hidden = !open;
      if (info) info.setAttribute("aria-expanded", open ? "true" : "false");
    }

    dock.querySelectorAll("[data-design-option]").forEach(function (button) {
      button.addEventListener("click", function () {
        setDesign(button.getAttribute("data-design-option"));
      });
    });

    if (info) {
      info.addEventListener("click", function () {
        setNotes(notes.hidden);
      });
    }
    if (close) {
      close.addEventListener("click", function () {
        setNotes(false);
      });
    }

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") setNotes(false);
    });

    setNotes(false);
    syncDesign(DESIGN_COLORS[root.dataset.design] ? root.dataset.design : "calm");
  }

  /* ------------------------------------------------------------
     Header + mobile navigation
     ------------------------------------------------------------ */
  var header = document.querySelector("[data-site-header]");
  if (header) {
    var onScroll = function () {
      header.classList.toggle("is-scrolled", window.scrollY > 12);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });

    var toggle = header.querySelector("[data-menu-toggle]");
    var panel = header.querySelector("#mobile-nav");
    var openIcon = header.querySelector("[data-menu-open-icon]");
    var closeIcon = header.querySelector("[data-menu-close-icon]");

    function setMenu(open) {
      if (!toggle || !panel) return;
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
      toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
      panel.hidden = !open;
      panel.classList.toggle("is-open", open);
      if (openIcon) openIcon.hidden = open;
      if (closeIcon) closeIcon.hidden = !open;
      document.body.style.overflow = open ? "hidden" : "";
    }

    if (toggle) {
      toggle.addEventListener("click", function () {
        setMenu(toggle.getAttribute("aria-expanded") !== "true");
      });
    }

    header.querySelectorAll(".mobile-link, .mobile-ask").forEach(function (link) {
      link.addEventListener("click", function () {
        setMenu(false);
      });
    });

    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape") setMenu(false);
    });
  }

  /* ------------------------------------------------------------
     Event tabs
     ------------------------------------------------------------ */
  var eventTabs = document.querySelector("[data-event-tabs]");
  if (eventTabs) {
    eventTabs.querySelectorAll("[data-event-tab]").forEach(function (button) {
      button.addEventListener("click", function () {
        var name = button.getAttribute("data-event-tab");

        eventTabs.querySelectorAll("[data-event-tab]").forEach(function (tab) {
          var active = tab === button;
          tab.classList.toggle("is-active", active);
          tab.setAttribute("aria-selected", active ? "true" : "false");
        });

        document.querySelectorAll("[data-event-panel]").forEach(function (list) {
          list.hidden = list.getAttribute("data-event-panel") !== name;
        });
      });
    });
  }

  /* ------------------------------------------------------------
     Conversation filters
     ------------------------------------------------------------ */
  var conversationFilters = document.querySelector("[data-conversation-filters]");
  if (conversationFilters) {
    var conversationGrid = document.querySelector("[data-conversation-grid]");
    var conversationCards = conversationGrid
      ? Array.prototype.slice.call(conversationGrid.querySelectorAll(".content-card"))
      : [];
    var conversationEmpty = document.querySelector("[data-conversation-empty]");

    function conversationMatches(filter, card) {
      if (filter === "all") return true;
      if (filter === "instagram" || filter === "linkedin") {
        return card.getAttribute("data-platform") === filter;
      }
      if (filter === "podcast") return card.getAttribute("data-kind") === "Podcast";
      if (filter === "expert") return card.getAttribute("data-kind") === "Expert Byte";
      if (filter === "mom") return card.getAttribute("data-kind") === "Mom Circle";
      return true;
    }

    conversationFilters.querySelectorAll("[data-filter]").forEach(function (button) {
      button.addEventListener("click", function () {
        var filter = button.getAttribute("data-filter");
        var visible = 0;

        conversationFilters.querySelectorAll("[data-filter]").forEach(function (chip) {
          var active = chip === button;
          chip.classList.toggle("is-active", active);
          chip.setAttribute("aria-pressed", active ? "true" : "false");
        });

        conversationCards.forEach(function (card) {
          var show = conversationMatches(filter, card);
          card.hidden = !show;
          card.classList.remove("content-card--featured");
          if (show) {
            visible += 1;
            if (visible === 1 && filter === "all") {
              card.classList.add("content-card--featured");
            }
          }
        });

        if (conversationEmpty) {
          conversationEmpty.hidden = visible > 0;
        }
      });
    });
  }

  /* ------------------------------------------------------------
     Expert directory filters
     ------------------------------------------------------------ */
  var expertGrid = document.querySelector("[data-expert-grid]");
  if (expertGrid) {
    var expertCards = Array.prototype.slice.call(expertGrid.querySelectorAll(".expert-card"));
    var expertSearch = document.querySelector("[data-expert-search]");
    var expertCount = document.querySelector("[data-expert-count]");
    var expertEmpty = document.querySelector("[data-expert-empty]");
    var expertReset = document.querySelector("[data-expert-reset]");
    var expertState = { query: "", group: "all", mode: "all" };

    function applyExpertFilters() {
      var query = expertState.query.trim().toLowerCase();
      var visible = 0;

      expertCards.forEach(function (card) {
        var group = card.getAttribute("data-group") || "";
        var mode = card.getAttribute("data-mode") || "";
        var search = card.getAttribute("data-search") || "";
        var show =
          (expertState.group === "all" || group === expertState.group) &&
          (expertState.mode === "all" || mode.indexOf(expertState.mode) !== -1) &&
          (!query || search.indexOf(query) !== -1);

        card.hidden = !show;
        if (show) visible += 1;
      });

      if (expertCount) {
        expertCount.textContent =
          visible +
          (visible === 1 ? " practitioner" : " practitioners") +
          (query ? " matching “" + expertState.query.trim() + "”" : "");
      }
      if (expertEmpty) expertEmpty.hidden = visible > 0;
    }

    document.querySelectorAll("[data-expert-groups] [data-group]").forEach(function (button) {
      button.addEventListener("click", function () {
        expertState.group = button.getAttribute("data-group");
        document.querySelectorAll("[data-expert-groups] [data-group]").forEach(function (chip) {
          var active = chip === button;
          chip.classList.toggle("is-active", active);
          chip.setAttribute("aria-pressed", active ? "true" : "false");
        });
        applyExpertFilters();
      });
    });

    document.querySelectorAll("[data-expert-modes] [data-mode]").forEach(function (button) {
      button.addEventListener("click", function () {
        expertState.mode = button.getAttribute("data-mode");
        document.querySelectorAll("[data-expert-modes] [data-mode]").forEach(function (chip) {
          var active = chip === button;
          chip.classList.toggle("is-active", active);
          chip.setAttribute("aria-pressed", active ? "true" : "false");
        });
        applyExpertFilters();
      });
    });

    if (expertSearch) {
      expertSearch.addEventListener("input", function () {
        expertState.query = expertSearch.value;
        applyExpertFilters();
      });
    }

    if (expertReset) {
      expertReset.addEventListener("click", function () {
        expertState = { query: "", group: "all", mode: "all" };
        if (expertSearch) expertSearch.value = "";
        document.querySelectorAll("[data-expert-groups] [data-group]").forEach(function (chip) {
          var active = chip.getAttribute("data-group") === "all";
          chip.classList.toggle("is-active", active);
          chip.setAttribute("aria-pressed", active ? "true" : "false");
        });
        document.querySelectorAll("[data-expert-modes] [data-mode]").forEach(function (chip) {
          var active = chip.getAttribute("data-mode") === "all";
          chip.classList.toggle("is-active", active);
          chip.setAttribute("aria-pressed", active ? "true" : "false");
        });
        applyExpertFilters();
      });
    }
  }

  /* ------------------------------------------------------------
     Ask flow
     ------------------------------------------------------------ */
  var askShell = document.querySelector("[data-ask-shell]");
  if (askShell) {
    var intentGrid = askShell.querySelector("[data-intent-grid]");
    var formCard = askShell.querySelector("[data-ask-form]");
    var successPanel = askShell.querySelector("[data-ask-success]");
    var askPanels = Array.prototype.slice.call(askShell.querySelectorAll("[data-ask-panel]"));
    var askSteps = Array.prototype.slice.call(askShell.querySelectorAll("[data-step]"));
    var eyebrowEl = askShell.querySelector("[data-ask-eyebrow]");
    var titleEl = askShell.querySelector("[data-ask-title]");
    var introEl = askShell.querySelector("[data-ask-intro]");
    var expertContext = askShell.querySelector("[data-expert-context]");
    var expertNameEl = expertContext ? expertContext.querySelector("strong") : null;
    var expertName = expertNameEl ? expertNameEl.textContent.trim() : "";
    var currentPath = askShell.getAttribute("data-initial-path") || "";

    var copy = {
      support: {
        eyebrow: "Private ask",
        title: expertName ? "Ask to connect with " + expertName : "Tell us what's going on.",
        intro: "You don't have to explain it perfectly. A real person on the team will read this.",
      },
      community: {
        eyebrow: "Community request",
        title: "Start with an introduction.",
        intro: "A sentence is enough. We'll reply with the right invite and what to expect.",
      },
      practitioner: {
        eyebrow: "Directory application",
        title: "Tell us about your work.",
        intro: "This is not a test of legitimacy. We want to understand how you work and who you work with.",
      },
    };

    function setProgress(step) {
      askSteps.forEach(function (el) {
        var number = Number(el.getAttribute("data-step"));
        el.classList.toggle("is-done", number <= step);
      });
    }

    function setAskUrl(path) {
      var url = new URL(window.location.href);
      if (path) {
        url.searchParams.set("path", path);
      } else {
        url.searchParams.delete("path");
        url.searchParams.delete("practitioner");
      }
      window.history.replaceState({}, "", url.toString());
    }

    function showPath(path, scroll) {
      if (!copy[path]) return;
      currentPath = path;
      intentGrid.hidden = true;
      formCard.hidden = false;
      successPanel.hidden = true;

      askPanels.forEach(function (panel) {
        panel.hidden = panel.getAttribute("data-ask-panel") !== path;
      });

      if (eyebrowEl) eyebrowEl.textContent = copy[path].eyebrow;
      if (titleEl) titleEl.textContent = copy[path].title;
      if (introEl) introEl.textContent = copy[path].intro;

      setProgress(2);
      setAskUrl(path);

      if (scroll) {
        askShell.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }

    function showIntents() {
      currentPath = "";
      formCard.hidden = true;
      successPanel.hidden = true;
      intentGrid.hidden = false;
      askPanels.forEach(function (panel) {
        panel.hidden = true;
      });
      setProgress(1);
      setAskUrl(null);
    }

    function resetForms() {
      askShell.querySelectorAll("form").forEach(function (form) {
        form.reset();
      });
      askShell.querySelectorAll("[data-error-for]").forEach(function (error) {
        error.hidden = true;
      });
      askShell.querySelectorAll("[data-chip-group] .chip").forEach(function (chip) {
        var isEnglish = chip.textContent.trim() === "English";
        var group = chip.closest("[data-chip-group]");
        var selected = isEnglish && group && group.getAttribute("data-chip-group") === "languages";
        chip.classList.toggle("is-selected", selected);
        chip.setAttribute("aria-pressed", selected ? "true" : "false");
      });
    }

    function setError(form, key, show) {
      var target = form.querySelector('[data-error-for="' + key + '"]');
      if (target) target.hidden = !show;
    }

    function showSuccess(path, options) {
      options = options || {};
      formCard.hidden = true;
      successPanel.hidden = false;
      setProgress(3);

      var title = successPanel.querySelector("[data-success-title]");
      var copyEl = successPanel.querySelector("[data-success-copy]");
      var whatsapp = successPanel.querySelector("[data-success-whatsapp]");
      var crisis = successPanel.querySelector("[data-success-crisis]");
      var reference = successPanel.querySelector("[data-success-reference]");

      var titles = {
        support: "Your ask is here.",
        community: "One step from the circle.",
        practitioner: "Application received.",
      };

      var body = "";
      if (path === "support") {
        body =
          "In the live portal, a real person from the team would read this and reply on " +
          (options.contact || "the contact you left") +
          ". Nothing has been sent in this demo — your note was not stored.";
      } else if (path === "community") {
        body =
          "The team would review this and send the current WhatsApp invite. In this demo, nothing is sent or stored.";
      } else {
        body =
          "The team would review your application and reply at " +
          (options.contact || "your email") +
          ". In this demo, nothing is sent or stored.";
      }

      if (title) title.textContent = titles[path];
      if (copyEl) copyEl.textContent = body;
      if (whatsapp) whatsapp.hidden = path !== "community";
      if (crisis) crisis.hidden = path !== "support";

      successPanel.querySelectorAll("[data-success-steps]").forEach(function (list) {
        list.hidden = list.getAttribute("data-success-steps") !== path;
      });

      if (reference) {
        reference.textContent = "PTL-" + Math.random().toString(36).slice(2, 7).toUpperCase();
      }

      window.scrollTo({ top: 0, behavior: "smooth" });
    }

    // Intent cards.
    askShell.querySelectorAll("[data-intent]").forEach(function (button) {
      button.addEventListener("click", function () {
        showPath(button.getAttribute("data-intent"), true);
      });
    });

    var backButton = askShell.querySelector("[data-ask-back]");
    if (backButton) {
      backButton.addEventListener("click", function () {
        showIntents();
        askShell.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    }

    // Multi-select chips.
    askShell.querySelectorAll("[data-chip-group] .chip").forEach(function (chip) {
      chip.addEventListener("click", function () {
        var selected = chip.classList.toggle("is-selected");
        chip.setAttribute("aria-pressed", selected ? "true" : "false");
        var group = chip.closest("[data-chip-group]");
        if (group) {
          var form = chip.closest("form");
          if (form) setError(form, group.getAttribute("data-chip-group"), false);
        }
      });
    });

    var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    var supportForm = askShell.querySelector('[data-ask-form-el="support"]');
    if (supportForm) {
      supportForm.addEventListener("submit", function (event) {
        event.preventDefault();
        supportForm.querySelectorAll("[data-error-for]").forEach(function (el) {
          el.hidden = true;
        });

        if (!supportForm.reportValidity()) return;

        var message = supportForm.querySelector("#support-message");
        var email = supportForm.querySelector("#support-email").value.trim();
        var whatsapp = supportForm.querySelector("#support-whatsapp").value.trim();
        var ok = true;

        if (!message || message.value.trim().length < 10) {
          setError(supportForm, "message", true);
          ok = false;
        }
        if (!email && !whatsapp) {
          setError(supportForm, "contact", true);
          ok = false;
        }
        if (email && !emailPattern.test(email)) {
          setError(supportForm, "contact", true);
          ok = false;
        }
        if (!ok) return;

        showSuccess("support", { contact: email || whatsapp });
      });
    }

    var communityForm = askShell.querySelector('[data-ask-form-el="community"]');
    if (communityForm) {
      communityForm.addEventListener("submit", function (event) {
        event.preventDefault();
        if (!communityForm.reportValidity()) return;
        var email = communityForm.querySelector("#community-email").value.trim();
        if (email && !emailPattern.test(email)) {
          communityForm.querySelector("#community-email").focus();
          return;
        }
        showSuccess("community");
      });
    }

    var practiceForm = askShell.querySelector('[data-ask-form-el="practitioner"]');
    if (practiceForm) {
      practiceForm.addEventListener("submit", function (event) {
        event.preventDefault();
        practiceForm.querySelectorAll("[data-error-for]").forEach(function (el) {
          el.hidden = true;
        });

        if (!practiceForm.reportValidity()) return;

        var ok = true;
        var modalityGroup = practiceForm.querySelector('[data-chip-group="modalities"]');
        var languageGroup = practiceForm.querySelector('[data-chip-group="languages"]');

        if (!modalityGroup || !modalityGroup.querySelector(".is-selected")) {
          setError(practiceForm, "modalities", true);
          ok = false;
        }
        if (!languageGroup || !languageGroup.querySelector(".is-selected")) {
          setError(practiceForm, "languages", true);
          ok = false;
        }
        if (!ok) return;

        var email = practiceForm.querySelector("#practice-email").value.trim();
        showSuccess("practitioner", { contact: email });
      });
    }

    var restart = askShell.querySelector("[data-ask-restart]");
    if (restart) {
      restart.addEventListener("click", function () {
        resetForms();
        if (expertContext) expertContext.hidden = true;
        expertName = "";
        showIntents();
        window.scrollTo({ top: 0, behavior: "smooth" });
      });
    }

    if (currentPath) {
      showPath(currentPath, false);
    } else {
      setProgress(1);
    }

    // Re-apply the correct support title when arriving with an expert.
    if (currentPath === "support" && expertName && titleEl) {
      titleEl.textContent = "Ask to connect with " + expertName;
    }

  }

  /* ------------------------------------------------------------
     RSVP demo
     ------------------------------------------------------------ */
  var rsvpCard = document.querySelector("[data-rsvp-card]");
  if (rsvpCard) {
    var rsvpForm = rsvpCard.querySelector("[data-rsvp-form]");
    var rsvpWrap = rsvpCard.querySelector("[data-rsvp-form-wrap]");
    var rsvpSuccess = rsvpCard.querySelector("[data-rsvp-success]");
    var rsvpEmail = rsvpCard.querySelector("[data-rsvp-recap-email]");

    function icsDate(value) {
      return new Date(value)
        .toISOString()
        .replace(/[-:]/g, "")
        .split(".")[0] + "Z";
    }

    function icsText(value) {
      return String(value)
        .replace(/\\/g, "\\\\")
        .replace(/;/g, "\\;")
        .replace(/,/g, "\\,")
        .replace(/\n/g, "\\n");
    }

    if (rsvpForm) {
      rsvpForm.addEventListener("submit", function (event) {
        event.preventDefault();
        if (!rsvpForm.reportValidity()) return;

        var email = rsvpForm.querySelector("[data-rsvp-email]");
        if (rsvpEmail) rsvpEmail.textContent = email && email.value ? email.value : "—";
        if (rsvpWrap) rsvpWrap.hidden = true;
        if (rsvpSuccess) {
          rsvpSuccess.hidden = false;
          rsvpSuccess.scrollIntoView({ behavior: "smooth", block: "nearest" });
        }
      });
    }

    var rsvpReset = rsvpCard.querySelector("[data-rsvp-reset]");
    if (rsvpReset) {
      rsvpReset.addEventListener("click", function () {
        if (rsvpForm) rsvpForm.reset();
        if (rsvpSuccess) rsvpSuccess.hidden = true;
        if (rsvpWrap) rsvpWrap.hidden = false;
      });
    }

    var calendar = rsvpCard.querySelector("[data-rsvp-calendar]");
    if (calendar) {
      calendar.addEventListener("click", function () {
        var title = rsvpCard.getAttribute("data-event-title") || "Puch Toh Lo circle";
        var start = rsvpCard.getAttribute("data-event-start");
        var end = rsvpCard.getAttribute("data-event-end");
        var location = rsvpCard.getAttribute("data-event-location") || "";
        var summary = rsvpCard.getAttribute("data-event-summary") || "";
        var slug = rsvpCard.getAttribute("data-event-slug") || "circle";

        if (!start || !end) return;

        var lines = [
          "BEGIN:VCALENDAR",
          "VERSION:2.0",
          "PRODID:-//Puch Toh Lo//Portal//EN",
          "CALSCALE:GREGORIAN",
          "BEGIN:VEVENT",
          "UID:" + slug + "@puchtohlo.com",
          "DTSTAMP:" + icsDate(new Date().toISOString()),
          "DTSTART:" + icsDate(start),
          "DTEND:" + icsDate(end),
          "SUMMARY:" + icsText(title + " — Puch Toh Lo"),
          "DESCRIPTION:" + icsText("A Puch Toh Lo circle. " + summary),
          "LOCATION:" + icsText(location),
          "END:VEVENT",
          "END:VCALENDAR",
        ];

        var blob = new Blob([lines.join("\r\n")], { type: "text/calendar;charset=utf-8" });
        var url = URL.createObjectURL(blob);
        var link = document.createElement("a");
        link.href = url;
        link.download = "puch-toh-lo-" + slug + ".ics";
        document.body.appendChild(link);
        link.click();
        link.remove();
        URL.revokeObjectURL(url);
      });
    }
  }
})();
