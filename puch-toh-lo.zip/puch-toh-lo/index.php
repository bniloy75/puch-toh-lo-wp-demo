<?php
/**
 * Fallback template.
 *
 * @package PuchTohLo
 */

get_header();
?>
<section class="section">
	<div class="container narrow">
		<p class="eyebrow">The archive</p>
		<h1 class="page-title"><?php is_home() ? esc_html_e( 'Notes from Puch Toh Lo', 'puch-toh-lo' ) : the_archive_title(); ?></h1>
		<div class="prose-block">
			<?php if ( have_posts() ) : ?>
				<?php while ( have_posts() ) : ?>
					<?php the_post(); ?>
					<article <?php post_class(); ?>>
						<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
						<?php the_excerpt(); ?>
					</article>
				<?php endwhile; ?>
				<?php the_posts_pagination(); ?>
			<?php else : ?>
				<?php ptl_empty_state( 'Nothing here yet', 'Try another page, or head back home.' ); ?>
			<?php endif; ?>
		</div>
	</div>
</section>
<?php
get_footer();
