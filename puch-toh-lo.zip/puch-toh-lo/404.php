<?php
/**
 * Not found.
 *
 * @package PuchTohLo
 */

get_header();
?>
<section class="section">
	<div class="container narrow">
		<p class="eyebrow">404</p>
		<h1 class="page-title">This page went quiet.</h1>
		<p class="page-intro">
			The link may be old. There are still circles, conversations and people to find.
		</p>
		<div class="hero-actions">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn-primary">
				<?php echo ptl_icon( 'arrow-left', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				Back to home
			</a>
			<a href="<?php echo esc_url( ptl_page_url( 'ask' ) ); ?>" class="btn btn-outline">Ask something</a>
		</div>
	</div>
</section>
<?php
get_footer();
