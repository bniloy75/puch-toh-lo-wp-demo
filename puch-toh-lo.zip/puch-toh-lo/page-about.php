<?php
/**
 * About page.
 *
 * @package PuchTohLo
 */

get_header();

$image_base = get_template_directory_uri() . '/assets/images/';

ptl_page_head(
	'About Puch Toh Lo',
	"A place to ask<br>before it becomes a crisis.",
	'Puch Toh Lo is a Pune-born space for honest questions about feelings, relationships and everyday mental health. It is the next chapter of The Healing Room — the same invitation, with a door you can open at any hour.',
	'<figure class="about-hero-figure"><img src="' . esc_url( $image_base . 'still-life.jpg' ) . '" alt="A quiet still life with a book, a cup and soft afternoon light"><figcaption>Ask. Listen. Belong.</figcaption></figure>'
);
?>

<section class="section">
	<div class="container about-story">
		<div class="about-story-copy">
			<p class="eyebrow">The idea</p>
			<h2 class="h2">The asking is the product.</h2>
			<p>
				Most of us wait too long. We wait until the loneliness has hardened into
				something physical, until the marriage feels like a shared address, until
				motherhood has swallowed the person underneath. Then we search, at 2am, for
				a word that describes it.
			</p>
			<p>
				Puch Toh Lo is an attempt to move the asking earlier. Not because a website
				can solve loneliness, but because it can shorten the distance between a
				feeling and the first useful conversation about it.
			</p>
			<p>
				The name is a nudge: <em>puch toh lo</em>. Just ask. It does not promise an
				answer for everything. It promises that the asking will not be met with
				silence.
			</p>
		</div>

		<aside class="about-principles">
			<div>
				<span>01</span>
				<h3>Ask</h3>
				<p>One door for support, community and practitioners. No quiz, no account.</p>
			</div>
			<div>
				<span>02</span>
				<h3>Listen</h3>
				<p>Circles, podcast episodes and short expert conversations.</p>
			</div>
			<div>
				<span>03</span>
				<h3>Belong</h3>
				<p>A directory of real people and a community that does not perform.</p>
			</div>
		</aside>
	</div>
</section>

<section class="section section--tint">
	<div class="container">
		<?php
		ptl_section_head(
			'What to expect',
			'Clear about what this is',
			'A portal can hold a lot. It should also be honest about its limits.'
		);
		?>
		<div class="is-isnt-grid">
			<div class="is-card">
				<h3>What this is</h3>
				<ul>
					<li>A starting point for questions you have been carrying alone.</li>
					<li>A small, curated directory of practitioners and peer supporters.</li>
					<li>Hosted circles, online and in Pune.</li>
					<li>A place where you can ask without giving your name.</li>
				</ul>
			</div>
			<div class="isnt-card">
				<h3>What this isn't</h3>
				<ul>
					<li>An emergency or crisis service. Call 112 if you are in danger.</li>
					<li>A replacement for therapy, diagnosis or medication.</li>
					<li>A social network designed to keep you scrolling.</li>
					<li>A directory of everyone. Listings are curated and reviewed.</li>
				</ul>
			</div>
		</div>
	</div>
</section>

<section class="section">
	<div class="container">
		<?php
		ptl_section_head(
			'How we hold trust',
			'Consent before contact.',
			'The portal is built around a few simple rules. They are not features; they are the baseline.'
		);
		?>
		<div class="values-grid">
			<article>
				<span class="value-icon"><?php echo ptl_icon( 'heart-handshake', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<h3>A person reads it</h3>
				<p>Requests are not scored or auto-routed. Someone on the team reads them and replies.</p>
			</article>
			<article>
				<span class="value-icon"><?php echo ptl_icon( 'shield-check', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<h3>Credentials, labelled</h3>
				<p>Where a registration applies, it is checked. Peer supporters are marked as non-clinical.</p>
			</article>
			<article>
				<span class="value-icon"><?php echo ptl_icon( 'users', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<h3>No forced community</h3>
				<p>Joining a WhatsApp group is optional. A circle RSVP does not add you to a group chat.</p>
			</article>
			<article>
				<span class="value-icon"><?php echo ptl_icon( 'message-circle', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<h3>Ask without a name</h3>
				<p>The support form lets you leave your name blank. We ask only for a way to reply.</p>
			</article>
		</div>
	</div>
</section>

<section class="section">
	<div class="container about-origin">
		<div class="about-origin-media">
			<img src="<?php echo esc_url( $image_base . 'workshop.jpg' ); ?>" alt="Hands painting with watercolours at a wooden table" loading="lazy">
		</div>
		<div class="about-origin-copy">
			<p class="eyebrow">From The Healing Room</p>
			<h2 class="h2">Same room. A wider door.</h2>
			<p>
				The Healing Room began with conversations that did not fit neatly into a
				clinic: mothers comparing notes, couples avoiding the real question, people
				who were not sure they were “unwell enough” to ask for help.
			</p>
			<p>
				Puch Toh Lo keeps that spirit and makes it easier to find. The portal brings
				the conversations, the circles and the practitioners into one place, so the
				first step is smaller.
			</p>
			<div class="about-origin-actions">
				<a href="<?php echo esc_url( ptl_page_url( 'ask' ) ); ?>" class="btn btn-primary">
					Ask something
					<?php echo ptl_icon( 'arrow-up-right', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</a>
				<a href="<?php echo esc_url( ptl_archive_url( 'expert' ) ); ?>" class="text-link">
					Meet the directory
					<?php echo ptl_icon( 'arrow-up-right', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</a>
			</div>
		</div>
	</div>
</section>

<section class="section">
	<div class="container narrow">
		<?php ptl_crisis_note(); ?>
		<p class="about-contact">
			For collaborations, practitioner questions or press:
			<a href="https://www.instagram.com/puchtohlo/" target="_blank" rel="noreferrer">send a DM on Instagram</a>.
			For community updates, <a href="<?php echo esc_url( ptl_page_url( 'ask' ) . '?path=community' ); ?>">request to join the WhatsApp circle</a>.
		</p>
	</div>
</section>

<?php
get_footer();
