<?php
/**
 * Content types used by the portal.
 *
 * @package PuchTohLo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Register experts, events and conversations.
 */
function ptl_register_post_types() {
	register_post_type(
		'expert',
		array(
			'labels'       => array(
				'name'          => __( 'Experts', 'puch-toh-lo' ),
				'singular_name' => __( 'Expert', 'puch-toh-lo' ),
				'add_new_item'  => __( 'Add an expert', 'puch-toh-lo' ),
				'edit_item'     => __( 'Edit expert', 'puch-toh-lo' ),
				'menu_name'     => __( 'Experts', 'puch-toh-lo' ),
			),
			'public'       => true,
			'has_archive'  => 'experts',
			'rewrite'      => array(
				'slug'       => 'experts',
				'with_front' => false,
			),
			'menu_icon'    => 'dashicons-groups',
			'supports'     => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
			'show_in_rest' => true,
		)
	);

	register_post_type(
		'event',
		array(
			'labels'       => array(
				'name'          => __( 'Circles & events', 'puch-toh-lo' ),
				'singular_name' => __( 'Circle', 'puch-toh-lo' ),
				'add_new_item'  => __( 'Add a circle or event', 'puch-toh-lo' ),
				'edit_item'     => __( 'Edit circle or event', 'puch-toh-lo' ),
				'menu_name'     => __( 'Circles & events', 'puch-toh-lo' ),
			),
			'public'       => true,
			'has_archive'  => 'events',
			'rewrite'      => array(
				'slug'       => 'events',
				'with_front' => false,
			),
			'menu_icon'    => 'dashicons-calendar-alt',
			'supports'     => array( 'title', 'editor', 'thumbnail' ),
			'show_in_rest' => true,
		)
	);

	register_post_type(
		'conversation',
		array(
			'labels'       => array(
				'name'          => __( 'Conversations', 'puch-toh-lo' ),
				'singular_name' => __( 'Conversation', 'puch-toh-lo' ),
				'add_new_item'  => __( 'Add a conversation', 'puch-toh-lo' ),
				'edit_item'     => __( 'Edit conversation', 'puch-toh-lo' ),
				'menu_name'     => __( 'Conversations', 'puch-toh-lo' ),
			),
			'public'       => true,
			'has_archive'  => 'conversations',
			'rewrite'      => array(
				'slug'       => 'conversations',
				'with_front' => false,
			),
			'menu_icon'    => 'dashicons-format-chat',
			'supports'     => array( 'title' ),
			'show_in_rest' => true,
		)
	);
}
add_action( 'init', 'ptl_register_post_types' );

/**
 * Conversations link out to the original platform.
 */
function ptl_redirect_conversation() {
	if ( is_singular( 'conversation' ) ) {
		$url = ptl_meta( get_queried_object_id(), 'url' );
		if ( $url ) {
			wp_redirect( esc_url_raw( $url ), 302 );
			exit;
		}
	}
}
add_action( 'template_redirect', 'ptl_redirect_conversation' );

/**
 * Ask and About are pages that ship with the theme.
 */
function ptl_ensure_pages() {
	if ( get_option( 'ptl_pages_ready' ) ) {
		return;
	}

	$pages = array(
		'ask'   => array(
			'title'   => 'Ask',
			'content' => 'One door for support, community or joining as a practitioner.',
		),
		'about' => array(
			'title'   => 'About Puch Toh Lo',
			'content' => 'A place to ask before it becomes a crisis.',
		),
	);

	foreach ( $pages as $slug => $page ) {
		if ( ! get_page_by_path( $slug ) ) {
			wp_insert_post(
				array(
					'post_type'    => 'page',
					'post_status'  => 'publish',
					'post_name'    => $slug,
					'post_title'   => $page['title'],
					'post_content' => $page['content'],
				)
			);
		}
	}

	update_option( 'ptl_pages_ready', 1 );
}
add_action( 'init', 'ptl_ensure_pages', 20 );
