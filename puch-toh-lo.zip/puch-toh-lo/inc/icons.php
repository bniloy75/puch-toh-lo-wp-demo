<?php
/**
 * Inline SVG icons used by the theme.
 *
 * @package PuchTohLo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Return an inline SVG icon.
 *
 * @param string $name Icon name.
 * @param int    $size Pixel size.
 * @return string
 */
function ptl_icon( $name, $size = 20 ) {
	$icons = array(
		'arrow-up-right'  => '<path d="M7 17 17 7"/><path d="M7 7h10v10"/>',
		'arrow-right'     => '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>',
		'arrow-left'      => '<path d="M19 12H5"/><path d="m11 18-6-6 6-6"/>',
		'check'           => '<path d="M20 6 9 17l-5-5"/>',
		'check-circle'    => '<circle cx="12" cy="12" r="9"/><path d="m8.5 12 2.5 2.5 5-5"/>',
		'clock'           => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
		'map-pin'         => '<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
		'users'           => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9"/><path d="M16 3.1a4 4 0 0 1 0 7.8"/>',
		'video'           => '<rect x="2" y="6" width="14" height="12" rx="3"/><path d="m16 10 6-3v10l-6-3"/>',
		'calendar'        => '<rect x="3" y="4" width="18" height="17" rx="3"/><path d="M8 2v4M16 2v4M3 10h18"/>',
		'calendar-plus'   => '<rect x="3" y="4" width="18" height="17" rx="3"/><path d="M8 2v4M16 2v4M3 10h18M12 14v4M10 16h4"/>',
		'ticket'          => '<path d="M3 9V7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v2a2 2 0 0 0 0 4v2a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-2a2 2 0 0 0 0-4Z"/><path d="M13 5v14"/>',
		'search'          => '<circle cx="11" cy="11" r="7"/><path d="m16.5 16.5 4.5 4.5"/>',
		'shield-check'    => '<path d="M12 3 5 6v5c0 5 3.4 8.3 7 10 3.6-1.7 7-5 7-10V6z"/><path d="m9 12 2 2 4-4"/>',
		'heart-handshake' => '<path d="M19.5 12.5 12 20l-7.5-7.5a4.5 4.5 0 0 1 6.4-6.4L12 7.2l1.1-1.1a4.5 4.5 0 0 1 6.4 6.4Z"/><path d="m8.5 12 3.5 3.5 3.5-3.5"/>',
		'message-circle'  => '<path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5 8.4 8.4 0 0 1-3.8-.9L3 21l1.9-5.7A8.4 8.4 0 0 1 4 11.5 8.5 8.5 0 0 1 12.5 3 8.5 8.5 0 0 1 21 11.5Z"/>',
		'briefcase'       => '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M3 12h18"/>',
		'sparkles'        => '<path d="m12 3 1.8 4.9L19 9.7l-5.2 1.8L12 16.4l-1.8-4.9L5 9.7l5.2-1.8z"/><path d="m19 15 .8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>',
		'x'               => '<path d="M18 6 6 18M6 6l12 12"/>',
		'menu'            => '<path d="M4 7h16M4 12h16M4 17h16"/>',
		'download'        => '<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/>',
		'alert-circle'    => '<circle cx="12" cy="12" r="9"/><path d="M12 7v6M12 17h.01"/>',
		'badge-check'     => '<path d="M12 3l2.4 1.6 2.8-.3 1 2.7 2.4 1.6-.9 2.8.9 2.8-2.4 1.6-1 2.7-2.8-.3L12 21l-2.4-1.6-2.8.3-1-2.7-2.4-1.6.9-2.8-.9-2.8 2.4-1.6 1-2.7 2.8.3z"/><path d="m9 12 2 2 4-4"/>',
		'languages'       => '<path d="m5 8 6 6"/><path d="m4 14 6-6 2-3"/><path d="M2 5h12"/><path d="M7 2h1"/><path d="m22 22-5-10-5 10"/><path d="M14 18h6"/>',
		'wallet'          => '<path d="M20 7V6a2 2 0 0 0-2-2H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v3"/><path d="M3 6v12a3 3 0 0 0 3 3h14a1 1 0 0 0 1-1v-5"/><path d="M16 14h5"/>',
		'phone'           => '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 2 .7 2.9a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.2-1.2a2 2 0 0 1 2.1-.5c.9.3 1.9.6 2.9.7a2 2 0 0 1 1.7 2Z"/>',
		'external-link'   => '<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>',
		'lock'            => '<rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
		'instagram'       => '<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.2" cy="6.8" r="1" fill="currentColor" stroke="none"/>',
		'youtube'         => '<rect x="2.5" y="5.5" width="19" height="13" rx="4"/><path d="M10.2 9.4l4.6 2.6-4.6 2.6z" fill="currentColor" stroke="none"/>',
		'linkedin'        => '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M7.5 10.5v6"/><circle cx="7.5" cy="7.6" r="1" fill="currentColor" stroke="none"/><path d="M11.5 16.5v-6"/><path d="M11.5 13.2c0-1.5 1-2.7 2.6-2.7s2.4 1.1 2.4 2.8v3.2"/>',
	);

	if ( ! isset( $icons[ $name ] ) ) {
		return '';
	}

	return sprintf(
		'<svg width="%1$d" height="%1$d" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">%2$s</svg>',
		(int) $size,
		$icons[ $name ]
	);
}
