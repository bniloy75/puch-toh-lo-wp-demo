<?php
/**
 * Demo content seeded from the portal prototype.
 *
 * @package PuchTohLo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Seed experts, circles, conversations and the two pages.
 *
 * @return void
 */
function ptl_seed_content() {
	if ( '1' === get_option( 'ptl_seed_version' ) ) {
		return;
	}

	$file = get_template_directory() . '/inc/seed-data.json';
	if ( ! file_exists( $file ) ) {
		return;
	}

	$json = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
	$data = json_decode( $json, true );

	if ( ! is_array( $data ) ) {
		return;
	}

	$expert_ids = array();

	if ( ! empty( $data['experts'] ) ) {
		foreach ( $data['experts'] as $index => $expert ) {
			$slug = sanitize_title( $expert['slug'] );
			$post = get_page_by_path( $slug, OBJECT, 'expert' );

			if ( $post ) {
				$expert_ids[ $slug ] = $post->ID;
				continue;
			}

			$bio = isset( $expert['bio'] ) ? implode( "\n\n", $expert['bio'] ) : '';

			$id = wp_insert_post(
				array(
					'post_type'    => 'expert',
					'post_status'  => 'publish',
					'post_name'    => $slug,
					'post_title'   => $expert['name'],
					'post_content' => $bio,
					'menu_order'   => $index,
				)
			);

			if ( is_wp_error( $id ) || ! $id ) {
				continue;
			}

			$expert_ids[ $slug ] = $id;

			$fields = array(
				'role'       => $expert['role'],
				'group'      => $expert['group'],
				'headline'   => $expert['headline'],
				'city'       => $expert['city'],
				'mode'       => $expert['mode'],
				'fee'        => $expert['fee'],
				'credential' => $expert['credential'],
				'languages'  => $expert['languages'],
				'focus'      => $expert['focus'],
				'modalities' => $expert['modalities'],
				'approach'   => $expert['approach'],
				'photo'      => isset( $expert['photo'] ) ? basename( $expert['photo'] ) : '',
				'initials'   => $expert['initials'],
				'tone'       => $expert['tone'],
				'featured'   => ! empty( $expert['featured'] ) ? 1 : 0,
				'sample'     => ! empty( $expert['sample'] ) ? 1 : 0,
			);

			foreach ( $fields as $key => $value ) {
				update_post_meta( $id, '_ptl_' . $key, $value );
			}
		}
	}

	if ( ! empty( $data['events'] ) ) {
		foreach ( $data['events'] as $event ) {
			$slug = sanitize_title( $event['slug'] );
			$post = get_page_by_path( $slug, OBJECT, 'event' );

			if ( $post ) {
				continue;
			}

			$description = isset( $event['description'] ) ? implode( "\n\n", $event['description'] ) : '';
			$host        = isset( $event['hostSlug'], $expert_ids[ $event['hostSlug'] ] ) ? $expert_ids[ $event['hostSlug'] ] : 0;

			$id = wp_insert_post(
				array(
					'post_type'    => 'event',
					'post_status'  => 'publish',
					'post_name'    => $slug,
					'post_title'   => $event['title'],
					'post_content' => $description,
				)
			);

			if ( is_wp_error( $id ) || ! $id ) {
				continue;
			}

			$fields = array(
				'kind'      => $event['kind'],
				'start'     => $event['start'],
				'end'       => $event['end'],
				'mode'      => $event['mode'],
				'location'  => $event['location'],
				'price'     => $event['price'],
				'capacity'  => (int) $event['capacity'],
				'taken'     => (int) $event['taken'],
				'host'      => (int) $host,
				'summary'   => $event['summary'],
				'expect'    => $event['expect'],
				'audience'  => $event['audience'],
				'image'     => isset( $event['image'] ) ? basename( $event['image'] ) : '',
				'recording' => isset( $event['recordingUrl'] ) ? $event['recordingUrl'] : '',
			);

			foreach ( $fields as $key => $value ) {
				update_post_meta( $id, '_ptl_' . $key, $value );
			}
		}
	}

	if ( ! empty( $data['content'] ) ) {
		foreach ( $data['content'] as $item ) {
			$slug = sanitize_title( $item['id'] );
			$post = get_page_by_path( $slug, OBJECT, 'conversation' );

			if ( $post ) {
				continue;
			}

			$id = wp_insert_post(
				array(
					'post_type'   => 'conversation',
					'post_status' => 'publish',
					'post_name'   => $slug,
					'post_title'  => $item['title'],
					'post_date'   => $item['date'] . ' 09:00:00',
				)
			);

			if ( is_wp_error( $id ) || ! $id ) {
				continue;
			}

			$fields = array(
				'platform' => $item['platform'],
				'kind'     => $item['kind'],
				'date'     => $item['date'],
				'url'      => $item['url'],
				'excerpt'  => $item['excerpt'],
				'image'    => isset( $item['image'] ) ? basename( $item['image'] ) : '',
				'sample'   => ! empty( $item['sample'] ) ? 1 : 0,
			);

			foreach ( $fields as $key => $value ) {
				update_post_meta( $id, '_ptl_' . $key, $value );
			}
		}
	}

	$pages = array(
		'ask'   => 'Ask',
		'about' => 'About Puch Toh Lo',
	);

	foreach ( $pages as $slug => $title ) {
		if ( ! get_page_by_path( $slug ) ) {
			wp_insert_post(
				array(
					'post_type'   => 'page',
					'post_status' => 'publish',
					'post_name'   => $slug,
					'post_title'  => $title,
				)
			);
		}
	}

	update_option( 'show_on_front', 'posts' );
	update_option( 'permalink_structure', '/%postname%/' );
	update_option( 'ptl_seed_version', '1' );

	flush_rewrite_rules();
}
