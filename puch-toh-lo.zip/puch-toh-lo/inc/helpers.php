<?php
/**
 * Theme helpers.
 *
 * @package PuchTohLo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Read a prefixed post meta value.
 *
 * @param int    $post_id Post ID.
 * @param string $key     Unprefixed key.
 * @param mixed  $default Fallback.
 * @return mixed
 */
function ptl_meta( $post_id, $key, $default = '' ) {
	$value = get_post_meta( (int) $post_id, '_ptl_' . $key, true );
	if ( '' === $value || null === $value ) {
		return $default;
	}
	return $value;
}

/**
 * Read a meta value as a list of lines.
 *
 * @param int    $post_id Post ID.
 * @param string $key     Unprefixed key.
 * @return array
 */
function ptl_lines( $post_id, $key ) {
	$value = ptl_meta( $post_id, $key, array() );
	if ( is_array( $value ) ) {
		return array_values( array_filter( array_map( 'trim', $value ) ) );
	}
	$lines = preg_split( '/\r\n|\r|\n/', (string) $value );
	return array_values( array_filter( array_map( 'trim', $lines ) ) );
}

/**
 * Read a checkbox-like meta value.
 *
 * @param int    $post_id Post ID.
 * @param string $key     Unprefixed key.
 * @return bool
 */
function ptl_flag( $post_id, $key ) {
	return (bool) ptl_meta( $post_id, $key, false );
}

/**
 * Resolve an image stored as a theme filename, attachment ID or URL.
 *
 * @param int    $post_id Post ID.
 * @param string $key     Unprefixed meta key.
 * @return string
 */
function ptl_image_url( $post_id, $key = 'photo' ) {
	if ( has_post_thumbnail( $post_id ) ) {
		$url = get_the_post_thumbnail_url( $post_id, 'large' );
		if ( $url ) {
			return $url;
		}
	}

	$value = ptl_meta( $post_id, $key );
	if ( ! $value ) {
		return '';
	}

	if ( is_numeric( $value ) ) {
		$url = wp_get_attachment_image_url( (int) $value, 'large' );
		if ( $url ) {
			return $url;
		}
	}

	if ( preg_match( '#^https?://#i', $value ) ) {
		return $value;
	}

	return get_template_directory_uri() . '/assets/images/' . rawurlencode( basename( $value ) );
}

/**
 * Parse an ISO date in the site's timezone.
 *
 * @param string $iso ISO date.
 * @return DateTimeImmutable|null
 */
function ptl_dt( $iso ) {
	if ( ! $iso ) {
		return null;
	}
	try {
		return new DateTimeImmutable( $iso, new DateTimeZone( 'Asia/Kolkata' ) );
	} catch ( Exception $e ) {
		return null;
	}
}

/**
 * Date block used by event cards.
 *
 * @param string $iso ISO date.
 * @return array
 */
function ptl_date_block( $iso ) {
	$dt = ptl_dt( $iso );
	if ( ! $dt ) {
		return array(
			'weekday' => '',
			'day'     => '',
			'month'     => '',
		);
	}
	return array(
		'weekday' => strtoupper( $dt->format( 'D' ) ),
		'day'     => $dt->format( 'j' ),
		'month'   => strtoupper( $dt->format( 'M' ) ),
	);
}

/**
 * Long date, e.g. Friday, 13 November 2026.
 *
 * @param string $iso ISO date.
 * @return string
 */
function ptl_format_long_date( $iso ) {
	$dt = ptl_dt( $iso );
	return $dt ? $dt->format( 'l, j F Y' ) : '';
}

/**
 * Short date, e.g. 13 Nov 2026.
 *
 * @param string $iso ISO date.
 * @return string
 */
function ptl_format_short_date( $iso ) {
	$dt = ptl_dt( $iso );
	return $dt ? $dt->format( 'j M Y' ) : '';
}

/**
 * Time, e.g. 11:00am.
 *
 * @param string $iso ISO date.
 * @return string
 */
function ptl_format_time( $iso ) {
	$dt = ptl_dt( $iso );
	return $dt ? strtolower( $dt->format( 'g:i A' ) ) : '';
}

/**
 * Time range in IST.
 *
 * @param string $start Start ISO.
 * @param string $end   End ISO.
 * @return string
 */
function ptl_format_time_range( $start, $end ) {
	if ( ! $start ) {
		return '';
	}
	return ptl_format_time( $start ) . ' – ' . ptl_format_time( $end ) . ' IST';
}

/**
 * Whether an event has started.
 *
 * @param string $iso Start ISO.
 * @return bool
 */
function ptl_is_past( $iso ) {
	$dt = ptl_dt( $iso );
	return $dt ? $dt->getTimestamp() < time() : false;
}

/**
 * Remaining spots.
 *
 * @param int $post_id Event ID.
 * @return int
 */
function ptl_spots_left( $post_id ) {
	$capacity = (int) ptl_meta( $post_id, 'capacity', 0 );
	$taken    = (int) ptl_meta( $post_id, 'taken', 0 );
	return max( 0, $capacity - $taken );
}

/**
 * All experts, ordered.
 *
 * @return WP_Post[]
 */
function ptl_get_experts() {
	return get_posts(
		array(
			'post_type'      => 'expert',
			'posts_per_page' => 100,
			'post_status'    => 'publish',
			'orderby'        => array(
				'menu_order' => 'ASC',
				'date'       => 'ASC',
			),
		)
	);
}

/**
 * All events ordered by start.
 *
 * @param string $order ASC or DESC.
 * @return WP_Post[]
 */
function ptl_get_events( $order = 'ASC' ) {
	return get_posts(
		array(
			'post_type'      => 'event',
			'posts_per_page' => 100,
			'post_status'    => 'publish',
			'meta_key'       => '_ptl_start',
			'orderby'        => 'meta_value',
			'order'          => 'DESC' === $order ? 'DESC' : 'ASC',
		)
	);
}

/**
 * All conversations ordered by date.
 *
 * @return WP_Post[]
 */
function ptl_get_conversations() {
	return get_posts(
		array(
			'post_type'      => 'conversation',
			'posts_per_page' => 100,
			'post_status'    => 'publish',
			'meta_key'       => '_ptl_date',
			'orderby'        => 'meta_value',
			'order'          => 'DESC',
		)
	);
}

/**
 * Get an expert post by its slug.
 *
 * @param string $slug Slug.
 * @return WP_Post|null
 */
function ptl_expert_by_slug( $slug ) {
	if ( ! $slug ) {
		return null;
	}
	$post = get_page_by_path( sanitize_title( $slug ), OBJECT, 'expert' );
	return $post ? $post : null;
}

/**
 * Event host.
 *
 * @param int $event_id Event ID.
 * @return WP_Post|null
 */
function ptl_event_host( $event_id ) {
	$host = (int) ptl_meta( $event_id, 'host', 0 );
	if ( $host ) {
		$post = get_post( $host );
		if ( $post && 'expert' === $post->post_type ) {
			return $post;
		}
	}
	return null;
}

/**
 * Platform metadata for conversations.
 *
 * @param string $platform Platform key.
 * @return array
 */
function ptl_platform_meta( $platform ) {
	$map = array(
		'youtube'   => array(
			'label' => 'YouTube',
			'icon'  => 'youtube',
		),
		'instagram' => array(
			'label' => 'Instagram',
			'icon'  => 'instagram',
		),
		'linkedin'  => array(
			'label' => 'LinkedIn',
			'icon'  => 'linkedin',
		),
	);
	return isset( $map[ $platform ] ) ? $map[ $platform ] : $map['youtube'];
}

/**
 * URL for a page by slug, with fallback.
 *
 * @param string $slug Page slug.
 * @return string
 */
function ptl_page_url( $slug ) {
	$page = get_page_by_path( $slug );
	return $page ? get_permalink( $page ) : home_url( '/' . $slug . '/' );
}

/**
 * Archive URLs with fallbacks.
 *
 * @param string $type Post type.
 * @return string
 */
function ptl_archive_url( $type ) {
	$url = get_post_type_archive_link( $type );
	if ( $url ) {
		return $url;
	}
	$map = array(
		'conversation' => '/conversations/',
		'event'        => '/events/',
		'expert'       => '/experts/',
	);
	return home_url( isset( $map[ $type ] ) ? $map[ $type ] : '/' );
}

/**
 * Navigation items.
 *
 * @return array
 */
function ptl_nav_items() {
	return array(
		array(
			'key'   => 'conversations',
			'label' => 'Conversations',
			'url'   => ptl_archive_url( 'conversation' ),
		),
		array(
			'key'   => 'events',
			'label' => 'Circles & events',
			'url'   => ptl_archive_url( 'event' ),
		),
		array(
			'key'   => 'experts',
			'label' => 'Experts',
			'url'   => ptl_archive_url( 'expert' ),
		),
		array(
			'key'   => 'about',
			'label' => 'About',
			'url'   => ptl_page_url( 'about' ),
		),
	);
}

/**
 * Whether a nav item is current.
 *
 * @param string $key Nav key.
 * @return bool
 */
function ptl_nav_active( $key ) {
	switch ( $key ) {
		case 'conversations':
			return is_post_type_archive( 'conversation' ) || is_singular( 'conversation' );
		case 'events':
			return is_post_type_archive( 'event' ) || is_singular( 'event' );
		case 'experts':
			return is_post_type_archive( 'expert' ) || is_singular( 'expert' );
		case 'about':
			return is_page( 'about' );
		case 'ask':
			return is_page( 'ask' );
	}
	return false;
}

/**
 * Site logo.
 *
 * @return void
 */
function ptl_logo() {
	?>
	<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo" aria-label="Puch Toh Lo — home">
		<span class="logo-mark" aria-hidden="true">?</span>
		<span class="logo-copy">
			<span class="logo-name">Puch Toh Lo</span>
			<span class="logo-origin">formerly The Healing Room</span>
		</span>
	</a>
	<?php
}

/**
 * Social links.
 *
 * @param bool $labelled Show text labels.
 * @return void
 */
function ptl_social_links( $labelled = true ) {
	$links = array(
		array(
			'icon'  => 'instagram',
			'label' => 'Instagram',
			'url'   => 'https://www.instagram.com/puchtohlo/',
		),
		array(
			'icon'  => 'youtube',
			'label' => 'YouTube',
			'url'   => 'https://www.youtube.com/channel/UCm8Pg8cyklHTMy5I0VENAPQ',
		),
		array(
			'icon'  => 'linkedin',
			'label' => 'LinkedIn',
			'url'   => 'https://in.linkedin.com/in/poojathehealingroom',
		),
	);
	?>
	<div class="social-links">
		<?php foreach ( $links as $link ) : ?>
			<a href="<?php echo esc_url( $link['url'] ); ?>" target="_blank" rel="noreferrer" aria-label="Puch Toh Lo on <?php echo esc_attr( $link['label'] ); ?>">
				<?php echo ptl_icon( $link['icon'], 17 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php if ( $labelled ) : ?><span><?php echo esc_html( $link['label'] ); ?></span><?php endif; ?>
			</a>
		<?php endforeach; ?>
	</div>
	<?php
}

/**
 * Section heading.
 *
 * @param string $eyebrow Eyebrow.
 * @param string $title   Title (may contain markup).
 * @param string $intro   Intro.
 * @param string $url     Optional link URL.
 * @param string $label   Optional link label.
 * @return void
 */
function ptl_section_head( $eyebrow, $title, $intro = '', $url = '', $label = '' ) {
	?>
	<header class="section-head">
		<div class="section-head-copy">
			<p class="eyebrow"><?php echo esc_html( $eyebrow ); ?></p>
			<h2 class="h2"><?php echo wp_kses_post( $title ); ?></h2>
			<?php if ( $intro ) : ?><p class="section-intro"><?php echo esc_html( $intro ); ?></p><?php endif; ?>
		</div>
		<?php if ( $url && $label ) : ?>
			<a class="text-link" href="<?php echo esc_url( $url ); ?>">
				<?php echo esc_html( $label ); ?>
				<?php echo ptl_icon( 'arrow-up-right', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</a>
		<?php endif; ?>
	</header>
	<?php
}

/**
 * Page heading.
 *
 * @param string $eyebrow Eyebrow.
 * @param string $title   Title (may contain markup).
 * @param string $intro   Intro.
 * @param string $aside   Aside markup (trusted).
 * @return void
 */
function ptl_page_head( $eyebrow, $title, $intro = '', $aside = '' ) {
	?>
	<div class="container">
		<header class="page-head">
			<div class="page-head-copy">
				<p class="eyebrow"><?php echo esc_html( $eyebrow ); ?></p>
				<h1 class="page-title"><?php echo wp_kses_post( $title ); ?></h1>
				<?php if ( $intro ) : ?><p class="page-intro"><?php echo esc_html( $intro ); ?></p><?php endif; ?>
			</div>
			<?php if ( $aside ) : ?><div class="page-head-aside"><?php echo $aside; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div><?php endif; ?>
		</header>
	</div>
	<?php
}

/**
 * Urgent support note.
 *
 * @param bool $compact Compact version.
 * @return void
 */
function ptl_crisis_note( $compact = false ) {
	?>
	<aside class="crisis-note" aria-label="Urgent support">
		<span class="crisis-icon" aria-hidden="true"><?php echo ptl_icon( 'phone', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
		<div>
			<strong>If you need urgent support</strong>
			<p>
				Tele-MANAS <a href="tel:14416">14416</a> is free and available 24×7 in multiple
				languages. If you or someone else is in immediate danger, call <a href="tel:112">112</a>.
			</p>
			<?php if ( ! $compact ) : ?>
				<p class="crisis-small">
					This portal is not an emergency service. It is a place to find community, a
					practitioner, or a person to talk to.
				</p>
			<?php endif; ?>
		</div>
	</aside>
	<?php
}

/**
 * Tag chip.
 *
 * @param string $label Label.
 * @return void
 */
function ptl_tag( $label ) {
	?>
	<span class="tag"><?php echo esc_html( $label ); ?></span>
	<?php
}

/**
 * Sample badge.
 *
 * @param string $label Label.
 * @return void
 */
function ptl_sample_badge( $label = 'Sample profile' ) {
	?>
	<span class="sample-badge"><?php echo esc_html( $label ); ?></span>
	<?php
}

/**
 * Expert card.
 *
 * @param WP_Post $post Expert post.
 * @param string  $attrs Extra attributes.
 * @return void
 */
function ptl_expert_card( $post, $attrs = '' ) {
	$name      = get_the_title( $post );
	$role      = ptl_meta( $post->ID, 'role' );
	$headline  = ptl_meta( $post->ID, 'headline' );
	$languages = ptl_lines( $post->ID, 'languages' );
	$mode      = ptl_meta( $post->ID, 'mode', 'Online' );
	$photo     = ptl_image_url( $post->ID, 'photo' );
	$initials  = ptl_meta( $post->ID, 'initials', 'PT' );
	$tone      = ptl_meta( $post->ID, 'tone', '#8a6a55' );
	$sample    = ptl_flag( $post->ID, 'sample' );
	?>
	<a href="<?php echo esc_url( get_permalink( $post ) ); ?>" class="expert-card" <?php echo $attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
		<div class="expert-media">
			<?php if ( $photo ) : ?>
				<img src="<?php echo esc_url( $photo ); ?>" alt="" loading="lazy">
			<?php else : ?>
				<span class="expert-initials" style="background-color: <?php echo esc_attr( $tone ); ?>" aria-hidden="true">
					<?php echo esc_html( $initials ); ?>
				</span>
			<?php endif; ?>
			<?php if ( $sample ) : ?><span class="sample-flag">Sample</span><?php endif; ?>
		</div>
		<div class="expert-info">
			<span class="expert-role"><?php echo esc_html( $role ); ?></span>
			<h3><?php echo esc_html( $name ); ?></h3>
			<p class="expert-headline"><?php echo esc_html( $headline ); ?></p>
			<p class="expert-meta">
				<?php echo esc_html( implode( ' · ', array_slice( $languages, 0, 2 ) ) ); ?>
				<span class="dot-sep" aria-hidden="true"></span>
				<?php echo esc_html( $mode ); ?>
			</p>
		</div>
		<span class="expert-arrow" aria-hidden="true">
			<?php echo ptl_icon( 'arrow-up-right', 17 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</span>
	</a>
	<?php
}

/**
 * Event card.
 *
 * @param WP_Post $post         Event post.
 * @param bool    $compact      Compact modifier.
 * @param bool    $show_summary Show summary.
 * @param string  $attrs        Extra attributes.
 * @return void
 */
function ptl_event_card( $post, $compact = false, $show_summary = true, $attrs = '' ) {
	$start  = ptl_meta( $post->ID, 'start' );
	$end    = ptl_meta( $post->ID, 'end' );
	$kind   = ptl_meta( $post->ID, 'kind', 'Circle' );
	$mode   = ptl_meta( $post->ID, 'mode', 'Online' );
	$date   = ptl_date_block( $start );
	$past   = ptl_is_past( $start );
	$left   = ptl_spots_left( $post->ID );
	$cap    = (int) ptl_meta( $post->ID, 'capacity', 0 );
	$price  = ptl_meta( $post->ID, 'price', '' );
	$summary = ptl_meta( $post->ID, 'summary' );
	$classes = 'event-card';
	if ( $compact ) {
		$classes .= ' event-card--compact';
	}
	if ( $past ) {
		$classes .= ' is-past';
	}
	?>
	<article class="<?php echo esc_attr( $classes ); ?>" <?php echo $attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
		<div class="event-date" aria-hidden="true">
			<span class="event-weekday"><?php echo esc_html( $date['weekday'] ); ?></span>
			<strong class="event-day"><?php echo esc_html( $date['day'] ); ?></strong>
			<span class="event-month"><?php echo esc_html( $date['month'] ); ?></span>
		</div>

		<div class="event-main">
			<div class="event-tags">
				<?php ptl_tag( $kind ); ?>
				<span class="event-mode">
					<?php echo 'Online' === $mode ? ptl_icon( 'video', 13 ) : ptl_icon( 'map-pin', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php echo esc_html( $mode ); ?>
				</span>
			</div>
			<h3 class="event-title">
				<a href="<?php echo esc_url( get_permalink( $post ) ); ?>"><?php echo esc_html( get_the_title( $post ) ); ?></a>
			</h3>
			<p class="event-time">
				<?php echo ptl_icon( 'clock', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<?php echo esc_html( ptl_format_time_range( $start, $end ) ); ?>
				<span class="dot-sep" aria-hidden="true"></span>
				<?php echo esc_html( $price ); ?>
			</p>
			<?php if ( $show_summary && $summary ) : ?><p class="event-summary"><?php echo esc_html( $summary ); ?></p><?php endif; ?>
			<p class="event-spots">
				<?php if ( $past ) : ?>
					This circle has closed
				<?php else : ?>
					<?php echo ptl_icon( 'users', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php echo $left > 0 ? esc_html( sprintf( '%d of %d spots left', $left, $cap ) ) : 'Waitlist open'; ?>
				<?php endif; ?>
			</p>
		</div>

		<div class="event-action">
			<a href="<?php echo esc_url( get_permalink( $post ) ); ?>" class="btn btn-outline btn-sm">
				<?php echo $past ? 'Read' : 'Details'; ?>
				<?php echo ptl_icon( 'arrow-up-right', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</a>
		</div>
	</article>
	<?php
}

/**
 * Conversation card.
 *
 * @param WP_Post $post         Conversation post.
 * @param bool    $featured     Featured modifier.
 * @param bool    $show_excerpt Show excerpt.
 * @param string  $attrs        Extra attributes.
 * @return void
 */
function ptl_content_card( $post, $featured = false, $show_excerpt = true, $attrs = '' ) {
	$platform = ptl_meta( $post->ID, 'platform', 'youtube' );
	$meta     = ptl_platform_meta( $platform );
	$is_video = 'youtube' === $platform;
	$url      = ptl_meta( $post->ID, 'url', get_permalink( $post ) );
	$kind     = ptl_meta( $post->ID, 'kind', 'Post' );
	$date     = ptl_meta( $post->ID, 'date', get_the_date( 'Y-m-d', $post ) );
	$excerpt  = ptl_meta( $post->ID, 'excerpt' );
	$image    = ptl_image_url( $post->ID, 'image' );
	$sample   = ptl_flag( $post->ID, 'sample' );
	$classes  = 'content-card';
	if ( $featured ) {
		$classes .= ' content-card--featured';
	}
	if ( ! $is_video ) {
		$classes .= ' content-card--quote';
	}
	?>
	<a class="<?php echo esc_attr( $classes ); ?>" href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noreferrer" aria-label="<?php echo esc_attr( get_the_title( $post ) . ' — open on ' . $meta['label'] ); ?>" <?php echo $attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
		<?php if ( $is_video ) : ?>
			<div class="content-media">
				<?php if ( $image ) : ?>
					<img src="<?php echo esc_url( $image ); ?>" alt="" loading="lazy">
				<?php else : ?>
					<span class="content-media-fallback" aria-hidden="true">PTL</span>
				<?php endif; ?>
				<span class="platform-pill">
					<?php echo ptl_icon( $meta['icon'], 13 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php echo esc_html( $meta['label'] ); ?>
				</span>
				<span class="watch-pill">Watch</span>
			</div>
		<?php else : ?>
			<div class="quote-media" aria-hidden="true">
				<span class="quote-glyph">“</span>
				<span class="platform-pill">
					<?php echo ptl_icon( $meta['icon'], 13 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php echo esc_html( $meta['label'] ); ?>
				</span>
			</div>
		<?php endif; ?>

		<div class="content-body">
			<div class="content-kicker">
				<span><?php echo esc_html( $kind ); ?></span>
				<span class="dot-sep" aria-hidden="true"></span>
				<span><?php echo esc_html( ptl_format_short_date( $date ) ); ?></span>
				<?php if ( $sample ) : ?><span class="sample-badge">Sample post</span><?php endif; ?>
			</div>
			<h3><?php echo esc_html( get_the_title( $post ) ); ?></h3>
			<?php if ( $show_excerpt && $excerpt ) : ?><p><?php echo esc_html( $excerpt ); ?></p><?php endif; ?>
			<span class="content-open">
				<?php echo $is_video ? 'Watch on YouTube' : 'Open ' . esc_html( $meta['label'] ); ?>
				<?php echo ptl_icon( 'arrow-up-right', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</span>
		</div>
	</a>
	<?php
}

/**
 * Small expert host card.
 *
 * @param WP_Post $post Expert post.
 * @return void
 */
function ptl_expert_mini( $post ) {
	$photo = ptl_image_url( $post->ID, 'photo' );
	?>
	<div class="expert-mini">
		<?php if ( $photo ) : ?>
			<img src="<?php echo esc_url( $photo ); ?>" alt="" loading="lazy">
		<?php else : ?>
			<span class="expert-mini-initials" style="background-color: <?php echo esc_attr( ptl_meta( $post->ID, 'tone', '#8a6a55' ) ); ?>">
				<?php echo esc_html( ptl_meta( $post->ID, 'initials', 'PT' ) ); ?>
			</span>
		<?php endif; ?>
		<div>
			<?php ptl_sample_badge( 'Sample host' ); ?>
			<p class="expert-mini-name"><?php echo esc_html( get_the_title( $post ) ); ?></p>
			<p class="expert-mini-role"><?php echo esc_html( ptl_meta( $post->ID, 'role' ) ); ?></p>
		</div>
	</div>
	<?php
}

/**
 * Empty state.
 *
 * @param string $title Title.
 * @param string $body  Body.
 * @param string $action Optional action markup.
 * @return void
 */
function ptl_empty_state( $title, $body, $action = '' ) {
	?>
	<div class="empty-state">
		<p class="empty-mark" aria-hidden="true">~</p>
		<h3><?php echo esc_html( $title ); ?></h3>
		<p><?php echo esc_html( $body ); ?></p>
		<?php echo $action; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	</div>
	<?php
}

/**
 * Floating design switcher.
 *
 * @return void
 */
function ptl_design_dock() {
	$designs = array(
		array(
			'id'    => 'calm',
			'label' => 'Calm',
			'note'  => 'Cream, sage and Fraunces. A room you want to sit in.',
		),
		array(
			'id'    => 'modern',
			'label' => 'Modern',
			'note'  => 'Warm off-white, coral and tight sans. Clear and current.',
		),
		array(
			'id'    => 'bold',
			'label' => 'Bold',
			'note'  => 'Deep green, gold and a big editorial serif. Hard to ignore.',
		),
	);
	?>
	<div class="design-dock" data-design-dock>
		<div class="design-notes" role="dialog" aria-label="Design directions" hidden>
			<div class="design-notes-head">
				<p>Three directions, one product</p>
				<button type="button" class="design-notes-close" data-design-close aria-label="Close design notes">
					<?php echo ptl_icon( 'x', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</button>
			</div>
			<p class="design-notes-sub">Same pages, same content. Only the visual language changes.</p>
			<?php foreach ( $designs as $option ) : ?>
				<button type="button" class="design-note" data-design-option="<?php echo esc_attr( $option['id'] ); ?>">
					<span class="design-swatch" data-swatch="<?php echo esc_attr( $option['id'] ); ?>" aria-hidden="true"></span>
					<span class="design-note-copy">
						<strong><?php echo esc_html( $option['label'] ); ?></strong>
						<span><?php echo esc_html( $option['note'] ); ?></span>
					</span>
					<span class="design-check"><?php echo ptl_icon( 'check', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				</button>
			<?php endforeach; ?>
			<p class="design-notes-foot">For client review. Your choice is remembered on this device.</p>
		</div>

		<div class="design-bar">
			<button type="button" class="design-info" data-design-info aria-expanded="false" aria-label="Open design directions">
				<?php echo ptl_icon( 'sparkles', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span>Design</span>
			</button>
			<div class="design-options" role="radiogroup" aria-label="Visual design direction">
				<?php foreach ( $designs as $option ) : ?>
					<button type="button" role="radio" aria-checked="false" class="design-option" data-design-option="<?php echo esc_attr( $option['id'] ); ?>" title="<?php echo esc_attr( $option['note'] ); ?>">
						<span class="design-swatch" data-swatch="<?php echo esc_attr( $option['id'] ); ?>" aria-hidden="true"></span>
						<?php echo esc_html( $option['label'] ); ?>
					</button>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	<?php
}
