<?php
/**
 * Editor fields for experts, events and conversations.
 *
 * @package PuchTohLo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Field definitions.
 *
 * @param string $post_type Post type.
 * @return array
 */
function ptl_meta_fields( $post_type ) {
	if ( 'expert' === $post_type ) {
		return array(
			'role'       => array(
				'label' => 'Role',
				'type'  => 'text',
				'help'  => 'e.g. Clinical psychologist',
			),
			'group'      => array(
				'label'   => 'Directory group',
				'type'    => 'select',
				'options' => array( 'Therapist', 'Coach', 'Facilitator', 'Peer supporter', 'Nutritionist' ),
			),
			'headline'   => array(
				'label' => 'One-line headline',
				'type'  => 'text',
			),
			'city'       => array(
				'label' => 'City',
				'type'  => 'text',
			),
			'mode'       => array(
				'label'   => 'Sessions',
				'type'    => 'select',
				'options' => array( 'Online', 'In person', 'Online & in person' ),
			),
			'fee'        => array(
				'label' => 'Fee',
				'type'  => 'text',
			),
			'credential' => array(
				'label' => 'Credentials & registration',
				'type'  => 'text',
			),
			'languages'  => array(
				'label' => 'Languages',
				'type'  => 'lines',
				'help'  => 'One per line.',
			),
			'focus'      => array(
				'label' => 'Focus areas',
				'type'  => 'lines',
				'help'  => 'One per line. Shown as chips on the profile.',
			),
			'modalities' => array(
				'label' => 'Modalities',
				'type'  => 'lines',
				'help'  => 'One per line.',
			),
			'approach'   => array(
				'label' => 'How they work',
				'type'  => 'lines',
				'help'  => 'One approach per line. Shown as a checklist.',
			),
			'photo'      => array(
				'label' => 'Photo',
				'type'  => 'text',
				'help'  => 'Theme filename (e.g. ananya.jpg), media URL, or set a featured image above.',
			),
			'initials'   => array(
				'label' => 'Initials (no photo)',
				'type'  => 'text',
			),
			'tone'       => array(
				'label' => 'Initials background',
				'type'  => 'color',
			),
			'featured'   => array(
				'label' => 'Show on the home page',
				'type'  => 'checkbox',
			),
			'sample'     => array(
				'label' => 'Mark as a sample profile',
				'type'  => 'checkbox',
			),
		);
	}

	if ( 'event' === $post_type ) {
		return array(
			'kind'         => array(
				'label'   => 'Kind',
				'type'    => 'select',
				'options' => array( 'Mom Circle', 'Listening Circle', 'Meetup', 'Workshop' ),
			),
			'start'        => array(
				'label' => 'Starts',
				'type'  => 'datetime-local',
			),
			'end'          => array(
				'label' => 'Ends',
				'type'  => 'datetime-local',
			),
			'mode'         => array(
				'label'   => 'Mode',
				'type'    => 'select',
				'options' => array( 'Online', 'In person' ),
			),
			'location'     => array(
				'label' => 'Where',
				'type'  => 'text',
			),
			'price'        => array(
				'label' => 'Cost',
				'type'  => 'text',
			),
			'capacity'     => array(
				'label' => 'Capacity',
				'type'  => 'number',
			),
			'taken'        => array(
				'label' => 'Spots taken (demo)',
				'type'  => 'number',
				'help'  => 'The RSVP form is presentation-only, so this number does not change by itself.',
			),
			'host'         => array(
				'label' => 'Host',
				'type'  => 'host',
			),
			'summary'      => array(
				'label' => 'Short summary',
				'type'  => 'textarea',
			),
			'expect'       => array(
				'label' => 'What to expect',
				'type'  => 'lines',
				'help'  => 'One item per line.',
			),
			'audience'     => array(
				'label' => "Who it's for",
				'type'  => 'textarea',
			),
			'image'        => array(
				'label' => 'Image',
				'type'  => 'text',
				'help'  => 'Theme filename, media URL, or set a featured image above.',
			),
			'recording'    => array(
				'label' => 'Recording URL (past circles)',
				'type'  => 'url',
			),
		);
	}

	if ( 'conversation' === $post_type ) {
		return array(
			'platform' => array(
				'label'   => 'Platform',
				'type'    => 'select',
				'options' => array( 'youtube', 'instagram', 'linkedin' ),
			),
			'kind'     => array(
				'label'   => 'Kind',
				'type'    => 'select',
				'options' => array( 'Podcast', 'Expert Byte', 'Mom Circle', 'Short', 'Post' ),
			),
			'date'     => array(
				'label' => 'Published',
				'type'  => 'date',
			),
			'url'      => array(
				'label' => 'Original URL',
				'type'  => 'url',
				'help'  => 'Cards link straight to this URL.',
			),
			'excerpt'  => array(
				'label' => 'Short description',
				'type'  => 'textarea',
			),
			'image'    => array(
				'label' => 'Thumbnail',
				'type'  => 'text',
				'help'  => 'Theme filename, media URL, or set a featured image above.',
			),
			'sample'   => array(
				'label' => 'Mark as a sample post',
				'type'  => 'checkbox',
			),
		);
	}

	return array();
}

/**
 * Register meta boxes.
 */
function ptl_add_meta_boxes() {
	$types = array(
		'expert'       => 'Expert details',
		'event'        => 'Circle details',
		'conversation' => 'Conversation details',
	);

	foreach ( $types as $type => $label ) {
		add_meta_box(
			'ptl-details',
			$label,
			'ptl_render_meta_box',
			$type,
			'normal',
			'high'
		);
	}
}
add_action( 'add_meta_boxes', 'ptl_add_meta_boxes' );

/**
 * Render the meta box.
 *
 * @param WP_Post $post Post.
 */
function ptl_render_meta_box( $post ) {
	$fields = ptl_meta_fields( $post->post_type );
	if ( ! $fields ) {
		return;
	}

	wp_nonce_field( 'ptl_save_meta', 'ptl_meta_nonce' );

	if ( 'expert' === $post->post_type ) {
		echo '<p style="margin-top:0;color:#50575e;">The main editor above is the “About” text. Add paragraphs normally.</p>';
	}
	if ( 'event' === $post->post_type ) {
		echo '<p style="margin-top:0;color:#50575e;">The main editor above is the “About this circle” text.</p>';
	}

	echo '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:4px 24px;">';

	foreach ( $fields as $key => $field ) {
		$value = ptl_meta( $post->ID, $key, '' );
		$id    = 'ptl-' . $key;
		$type  = isset( $field['type'] ) ? $field['type'] : 'text';
		$help  = isset( $field['help'] ) ? $field['help'] : '';

		echo '<p style="margin:10px 0;">';
		echo '<label for="' . esc_attr( $id ) . '" style="display:block;font-weight:600;margin-bottom:4px;">' . esc_html( $field['label'] ) . '</label>';

		if ( 'textarea' === $type ) {
			echo '<textarea class="widefat" rows="3" id="' . esc_attr( $id ) . '" name="ptl[' . esc_attr( $key ) . ']">' . esc_textarea( is_array( $value ) ? implode( "\n", $value ) : $value ) . '</textarea>';
		} elseif ( 'lines' === $type ) {
			$text = is_array( $value ) ? implode( "\n", $value ) : $value;
			echo '<textarea class="widefat" rows="4" id="' . esc_attr( $id ) . '" name="ptl[' . esc_attr( $key ) . ']">' . esc_textarea( $text ) . '</textarea>';
		} elseif ( 'select' === $type ) {
			echo '<select class="widefat" id="' . esc_attr( $id ) . '" name="ptl[' . esc_attr( $key ) . ']">';
			$options = isset( $field['options'] ) ? $field['options'] : array();
			foreach ( $options as $option ) {
				echo '<option value="' . esc_attr( $option ) . '" ' . selected( $value, $option, false ) . '>' . esc_html( $option ) . '</option>';
			}
			echo '</select>';
		} elseif ( 'checkbox' === $type ) {
			echo '<label><input type="checkbox" id="' . esc_attr( $id ) . '" name="ptl[' . esc_attr( $key ) . ']" value="1" ' . checked( (bool) $value, true, false ) . '> Yes</label>';
		} elseif ( 'host' === $type ) {
			$experts = ptl_get_experts();
			echo '<select class="widefat" id="' . esc_attr( $id ) . '" name="ptl[' . esc_attr( $key ) . ']">';
			echo '<option value="0">— No host selected —</option>';
			foreach ( $experts as $expert ) {
				echo '<option value="' . esc_attr( $expert->ID ) . '" ' . selected( (int) $value, (int) $expert->ID, false ) . '>' . esc_html( get_the_title( $expert ) ) . '</option>';
			}
			echo '</select>';
		} elseif ( 'datetime-local' === $type ) {
			$display = '';
			$dt      = ptl_dt( $value );
			if ( $dt ) {
				$display = $dt->format( 'Y-m-d\TH:i' );
			}
			echo '<input class="widefat" type="datetime-local" id="' . esc_attr( $id ) . '" name="ptl[' . esc_attr( $key ) . ']" value="' . esc_attr( $display ) . '">';
		} elseif ( 'date' === $type ) {
			$display = '';
			$dt      = ptl_dt( $value );
			if ( $dt ) {
				$display = $dt->format( 'Y-m-d' );
			}
			echo '<input class="widefat" type="date" id="' . esc_attr( $id ) . '" name="ptl[' . esc_attr( $key ) . ']" value="' . esc_attr( $display ) . '">';
		} elseif ( 'number' === $type ) {
			echo '<input class="widefat" type="number" min="0" id="' . esc_attr( $id ) . '" name="ptl[' . esc_attr( $key ) . ']" value="' . esc_attr( $value ) . '">';
		} elseif ( 'color' === $type ) {
			echo '<input type="color" id="' . esc_attr( $id ) . '" name="ptl[' . esc_attr( $key ) . ']" value="' . esc_attr( $value ? $value : '#8a6a55' ) . '">';
		} elseif ( 'url' === $type ) {
			echo '<input class="widefat" type="url" id="' . esc_attr( $id ) . '" name="ptl[' . esc_attr( $key ) . ']" value="' . esc_attr( $value ) . '" placeholder="https://">';
		} else {
			echo '<input class="widefat" type="text" id="' . esc_attr( $id ) . '" name="ptl[' . esc_attr( $key ) . ']" value="' . esc_attr( $value ) . '">';
		}

		if ( $help ) {
			echo '<span style="display:block;color:#646970;font-size:12px;margin-top:3px;">' . esc_html( $help ) . '</span>';
		}
		echo '</p>';
	}

	echo '</div>';
}

/**
 * Save meta fields.
 *
 * @param int $post_id Post ID.
 */
function ptl_save_meta( $post_id ) {
	if ( ! isset( $_POST['ptl_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ptl_meta_nonce'] ) ), 'ptl_save_meta' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$post_type = get_post_type( $post_id );
	$fields    = ptl_meta_fields( $post_type );
	if ( ! $fields ) {
		return;
	}

	$raw = isset( $_POST['ptl'] ) ? wp_unslash( $_POST['ptl'] ) : array();

	foreach ( $fields as $key => $field ) {
		$type  = isset( $field['type'] ) ? $field['type'] : 'text';
		$value = isset( $raw[ $key ] ) ? $raw[ $key ] : '';

		if ( 'checkbox' === $type ) {
			update_post_meta( $post_id, '_ptl_' . $key, ! empty( $value ) ? 1 : 0 );
			continue;
		}

		if ( 'lines' === $type ) {
			$lines = preg_split( '/\r\n|\r|\n/', (string) $value );
			$lines = array_values( array_filter( array_map( 'sanitize_text_field', $lines ) ) );
			update_post_meta( $post_id, '_ptl_' . $key, $lines );
			continue;
		}

		if ( 'textarea' === $type ) {
			update_post_meta( $post_id, '_ptl_' . $key, sanitize_textarea_field( $value ) );
			continue;
		}

		if ( 'url' === $type ) {
			update_post_meta( $post_id, '_ptl_' . $key, esc_url_raw( $value ) );
			continue;
		}

		if ( 'number' === $type ) {
			update_post_meta( $post_id, '_ptl_' . $key, absint( $value ) );
			continue;
		}

		if ( 'host' === $type ) {
			update_post_meta( $post_id, '_ptl_' . $key, absint( $value ) );
			continue;
		}

		if ( 'select' === $type ) {
			$options = isset( $field['options'] ) ? $field['options'] : array();
			if ( in_array( $value, $options, true ) ) {
				update_post_meta( $post_id, '_ptl_' . $key, sanitize_text_field( $value ) );
			}
			continue;
		}

		if ( 'datetime-local' === $type ) {
			$value = sanitize_text_field( $value );
			if ( $value ) {
				$value = str_replace( 'T', ' ', $value ) . ':00+05:30';
			}
			update_post_meta( $post_id, '_ptl_' . $key, $value );
			continue;
		}

		if ( 'date' === $type ) {
			update_post_meta( $post_id, '_ptl_' . $key, sanitize_text_field( $value ) );
			continue;
		}

		if ( 'color' === $type ) {
			$value = sanitize_hex_color( $value );
			update_post_meta( $post_id, '_ptl_' . $key, $value ? $value : '#8a6a55' );
			continue;
		}

		update_post_meta( $post_id, '_ptl_' . $key, sanitize_text_field( $value ) );
	}
}
add_action( 'save_post_expert', 'ptl_save_meta' );
add_action( 'save_post_event', 'ptl_save_meta' );
add_action( 'save_post_conversation', 'ptl_save_meta' );

/**
 * Helpful admin columns.
 *
 * @param array $columns Columns.
 * @return array
 */
function ptl_admin_columns( $columns ) {
	$screen = get_current_screen();
	if ( ! $screen ) {
		return $columns;
	}

	if ( 'expert' === $screen->post_type ) {
		return array(
			'cb'       => $columns['cb'],
			'title'    => 'Name',
			'ptl_role' => 'Role',
			'ptl_group'=> 'Group',
			'date'     => $columns['date'],
		);
	}

	if ( 'event' === $screen->post_type ) {
		return array(
			'cb'       => $columns['cb'],
			'title'    => 'Circle',
			'ptl_start'=> 'Starts',
			'ptl_kind' => 'Kind',
			'date'     => $columns['date'],
		);
	}

	if ( 'conversation' === $screen->post_type ) {
		return array(
			'cb'         => $columns['cb'],
			'title'      => 'Title',
			'ptl_platform'=> 'Platform',
			'ptl_date'   => 'Date',
		);
	}

	return $columns;
}
add_filter( 'manage_expert_posts_columns', 'ptl_admin_columns' );
add_filter( 'manage_event_posts_columns', 'ptl_admin_columns' );
add_filter( 'manage_conversation_posts_columns', 'ptl_admin_columns' );

/**
 * Render admin columns.
 *
 * @param string $column  Column key.
 * @param int    $post_id Post ID.
 */
function ptl_admin_column_content( $column, $post_id ) {
	if ( 'ptl_role' === $column ) {
		echo esc_html( ptl_meta( $post_id, 'role' ) );
	}
	if ( 'ptl_group' === $column ) {
		echo esc_html( ptl_meta( $post_id, 'group' ) );
	}
	if ( 'ptl_start' === $column ) {
		echo esc_html( ptl_format_long_date( ptl_meta( $post_id, 'start' ) ) );
	}
	if ( 'ptl_kind' === $column ) {
		echo esc_html( ptl_meta( $post_id, 'kind' ) );
	}
	if ( 'ptl_platform' === $column ) {
		$meta = ptl_platform_meta( ptl_meta( $post_id, 'platform' ) );
		echo esc_html( $meta['label'] );
	}
	if ( 'ptl_date' === $column ) {
		echo esc_html( ptl_format_short_date( ptl_meta( $post_id, 'date' ) ) );
	}
}
add_action( 'manage_expert_posts_custom_column', 'ptl_admin_column_content', 10, 2 );
add_action( 'manage_event_posts_custom_column', 'ptl_admin_column_content', 10, 2 );
add_action( 'manage_conversation_posts_custom_column', 'ptl_admin_column_content', 10, 2 );
