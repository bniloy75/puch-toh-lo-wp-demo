<?php
/**
 * Conversations archive.
 *
 * @package PuchTohLo
 */

get_header();

$items   = ptl_get_conversations();
$count   = count( $items );
$filters = array(
	'all'       => 'Everything',
	'podcast'   => 'Podcast',
	'expert'    => 'Expert Bytes',
	'mom'       => 'Mom Circle',
	'instagram' => 'Instagram',
	'linkedin'  => 'LinkedIn',
);

$aside = '<div class="page-head-stat"><strong>' . esc_html( $count ) . '</strong><span>pieces in the archive</span><span class="page-head-stat-note">YouTube · Instagram · LinkedIn</span></div>';

ptl_page_head(
	'The archive',
	"Conversations,<br>in one place.",
	'Podcast episodes, Expert Bytes, Mom Circle reflections and posts from across our channels. Watch, listen, or send one to someone who needs it.',
	$aside
);
?>

<div class="container">
	<div class="filter-row" role="group" aria-label="Filter conversations" data-conversation-filters>
		<?php foreach ( $filters as $id => $label ) : ?>
			<button type="button" class="filter-chip <?php echo 'all' === $id ? 'is-active' : ''; ?>" data-filter="<?php echo esc_attr( $id ); ?>" aria-pressed="<?php echo 'all' === $id ? 'true' : 'false'; ?>">
				<?php echo esc_html( $label ); ?>
			</button>
		<?php endforeach; ?>
	</div>

	<?php if ( $items ) : ?>
		<div class="archive-grid" data-conversation-grid>
			<?php foreach ( $items as $index => $item ) : ?>
				<?php
				$kind     = ptl_meta( $item->ID, 'kind' );
				$platform = ptl_meta( $item->ID, 'platform' );
				$attrs    = 'data-kind="' . esc_attr( $kind ) . '" data-platform="' . esc_attr( $platform ) . '"';
				ptl_content_card( $item, 0 === $index, true, $attrs );
				?>
			<?php endforeach; ?>
		</div>
		<p class="archive-empty" data-conversation-empty hidden>Nothing here yet. Try a different filter.</p>
	<?php else : ?>
		<?php ptl_empty_state( 'No conversations yet', 'Add a podcast episode, a short or a post to start the archive.' ); ?>
	<?php endif; ?>

	<p class="feed-note">
		<strong>How the feed works:</strong> video titles and dates come from the live
		Puch Toh Lo YouTube channel. Instagram and LinkedIn cards are illustrative in
		this prototype; in the live portal, Instagram syncs from a Business account and
		LinkedIn is curated manually.
	</p>
</div>

<section class="section follow-section">
	<div class="container">
		<div class="follow-grid">
			<a class="follow-card" href="https://www.instagram.com/puchtohlo/" target="_blank" rel="noreferrer">
				<?php echo ptl_icon( 'instagram', 22 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span>
					<strong>Instagram</strong>
					<span>@puchtohlo · daily posts and reminders</span>
				</span>
				<?php echo ptl_icon( 'arrow-up-right', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</a>
			<a class="follow-card" href="https://www.youtube.com/channel/UCm8Pg8cyklHTMy5I0VENAPQ" target="_blank" rel="noreferrer">
				<?php echo ptl_icon( 'youtube', 22 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span>
					<strong>YouTube</strong>
					<span>Podcast, Expert Bytes, Mom Circle feedback</span>
				</span>
				<?php echo ptl_icon( 'arrow-up-right', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</a>
			<a class="follow-card" href="https://in.linkedin.com/in/poojathehealingroom" target="_blank" rel="noreferrer">
				<?php echo ptl_icon( 'linkedin', 22 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span>
					<strong>LinkedIn</strong>
					<span>Founder notes and longer thoughts</span>
				</span>
				<?php echo ptl_icon( 'arrow-up-right', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</a>
		</div>
	</div>
</section>

<?php
get_footer();
