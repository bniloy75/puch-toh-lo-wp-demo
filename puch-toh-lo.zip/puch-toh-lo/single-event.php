<?php
/**
 * Single circle / event.
 *
 * @package PuchTohLo
 */

get_header();

while ( have_posts() ) :
	the_post();

	$event_id   = get_the_ID();
	$start      = ptl_meta( $event_id, 'start' );
	$end        = ptl_meta( $event_id, 'end' );
	$kind       = ptl_meta( $event_id, 'kind', 'Circle' );
	$mode       = ptl_meta( $event_id, 'mode', 'Online' );
	$location   = ptl_meta( $event_id, 'location' );
	$price      = ptl_meta( $event_id, 'price' );
	$summary    = ptl_meta( $event_id, 'summary' );
	$capacity   = (int) ptl_meta( $event_id, 'capacity', 0 );
	$image      = ptl_image_url( $event_id, 'image' );
	$recording  = ptl_meta( $event_id, 'recording' );
	$host       = ptl_event_host( $event_id );
	$past       = ptl_is_past( $start );
	$left       = ptl_spots_left( $event_id );
	$full       = 0 === $left;
	$slug       = get_post_field( 'post_name', $event_id );
	?>
	<article class="event-detail">
		<div class="container">
			<nav class="breadcrumb" aria-label="Breadcrumb">
				<a href="<?php echo esc_url( ptl_archive_url( 'event' ) ); ?>">Circles &amp; events</a>
				<span aria-hidden="true">/</span>
				<span><?php echo esc_html( $kind ); ?></span>
			</nav>

			<header class="event-detail-head">
				<div class="event-detail-heading">
					<div class="event-tags">
						<?php ptl_tag( $kind ); ?>
						<span class="event-mode">
							<?php echo 'Online' === $mode ? ptl_icon( 'video', 13 ) : ptl_icon( 'map-pin', 13 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<?php echo esc_html( $mode ); ?>
						</span>
						<?php if ( $past ) : ?><span class="status-pill status-pill--muted">Closed</span><?php endif; ?>
					</div>
					<h1 class="page-title"><?php the_title(); ?></h1>
					<p class="page-intro"><?php echo esc_html( $summary ); ?></p>
				</div>
			</header>

			<div class="event-facts">
				<div>
					<span class="fact-icon"><?php echo ptl_icon( 'calendar', 17 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<span class="fact-label">Date</span>
					<strong><?php echo esc_html( ptl_format_long_date( $start ) ); ?></strong>
				</div>
				<div>
					<span class="fact-icon"><?php echo ptl_icon( 'clock', 17 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<span class="fact-label">Time</span>
					<strong><?php echo esc_html( ptl_format_time_range( $start, $end ) ); ?></strong>
				</div>
				<div>
					<span class="fact-icon"><?php echo ptl_icon( 'map-pin', 17 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<span class="fact-label">Where</span>
					<strong><?php echo esc_html( $location ); ?></strong>
				</div>
				<div>
					<span class="fact-icon"><?php echo ptl_icon( 'ticket', 17 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<span class="fact-label">Cost</span>
					<strong><?php echo esc_html( $price ); ?></strong>
				</div>
			</div>

			<div class="event-detail-body">
				<div class="event-detail-main">
					<?php if ( $image ) : ?>
						<figure class="event-hero-figure">
							<img src="<?php echo esc_url( $image ); ?>" alt="">
						</figure>
					<?php endif; ?>

					<section class="prose-block">
						<h2>About this circle</h2>
						<?php echo apply_filters( 'the_content', get_the_content() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</section>

					<?php if ( ptl_lines( $event_id, 'expect' ) ) : ?>
						<section class="prose-block">
							<h2>What to expect</h2>
							<ul class="check-list">
								<?php foreach ( ptl_lines( $event_id, 'expect' ) as $item ) : ?>
									<li>
										<?php echo ptl_icon( 'check-circle', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
										<?php echo esc_html( $item ); ?>
									</li>
								<?php endforeach; ?>
							</ul>
						</section>
					<?php endif; ?>

					<section class="prose-block">
						<h2>Who it's for</h2>
						<p><?php echo esc_html( ptl_meta( $event_id, 'audience' ) ); ?></p>
					</section>

					<?php if ( $host ) : ?>
						<section class="prose-block">
							<h2>Your host</h2>
							<?php ptl_expert_mini( $host ); ?>
							<a href="<?php echo esc_url( get_permalink( $host ) ); ?>" class="text-link host-link">
								Read <?php echo esc_html( explode( ' ', preg_replace( '/^Dr\.\s*/', '', get_the_title( $host ) ) )[0] ); ?>'s profile
								<?php echo ptl_icon( 'arrow-up-right', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							</a>
						</section>
					<?php endif; ?>

					<?php ptl_crisis_note( true ); ?>
				</div>

				<aside class="event-aside" aria-label="RSVP">
					<div class="rsvp-card" data-rsvp-card data-event-title="<?php echo esc_attr( get_the_title() ); ?>" data-event-start="<?php echo esc_attr( $start ); ?>" data-event-end="<?php echo esc_attr( $end ); ?>" data-event-location="<?php echo esc_attr( $location ); ?>" data-event-summary="<?php echo esc_attr( $summary ); ?>" data-event-slug="<?php echo esc_attr( $slug ); ?>">
						<?php if ( $past ) : ?>
							<p class="eyebrow">Closed</p>
							<h2 class="rsvp-title">This circle has ended.</h2>
							<p class="rsvp-copy">
								The room is closed, but the conversation continues. Browse what's
								coming up next.
							</p>
							<?php if ( $recording ) : ?>
								<a class="btn btn-primary btn-block" href="<?php echo esc_url( $recording ); ?>" target="_blank" rel="noreferrer">
									Watch the reflection
									<?php echo ptl_icon( 'arrow-up-right', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								</a>
							<?php endif; ?>
							<a href="<?php echo esc_url( ptl_archive_url( 'event' ) ); ?>" class="btn btn-outline btn-block">See upcoming circles</a>
						<?php else : ?>
							<div data-rsvp-form-wrap>
								<div class="rsvp-head">
									<div>
										<p class="eyebrow"><?php echo $full ? 'Waitlist' : 'Reserve a spot'; ?></p>
										<h2 class="rsvp-title"><?php echo $full ? 'Join the waitlist' : 'Reserve a spot'; ?></h2>
									</div>
									<span class="rsvp-spots">
										<?php echo ptl_icon( 'users', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
										<?php echo $full ? 'Full' : esc_html( sprintf( '%d left', $left ) ); ?>
									</span>
								</div>
								<p class="rsvp-copy">
									<?php echo $full ? 'This circle is full. Join the waitlist and we would email if a spot opens.' : 'No payment, no perfect words. Just tell us where to send the link.'; ?>
								</p>

								<form class="rsvp-form" data-rsvp-form novalidate>
									<div class="field">
										<label for="rsvp-name">Your name</label>
										<input id="rsvp-name" class="input" name="name" autocomplete="name" required data-rsvp-name>
									</div>
									<div class="field">
										<label for="rsvp-email">Email</label>
										<input id="rsvp-email" class="input" type="email" name="email" autocomplete="email" required data-rsvp-email>
									</div>
									<div class="field">
										<label for="rsvp-whatsapp">WhatsApp <span class="label-note">optional</span></label>
										<input id="rsvp-whatsapp" class="input" type="tel" name="whatsapp" autocomplete="tel">
									</div>
									<div class="field">
										<label for="rsvp-question">Anything you want the host to know? <span class="label-note">optional</span></label>
										<textarea id="rsvp-question" class="input textarea" name="question" rows="3"></textarea>
									</div>
									<label class="check-row">
										<input type="checkbox" name="consent" required>
										<span>I agree to be contacted about this circle. I can cancel any time.</span>
									</label>
									<button type="submit" class="btn btn-primary btn-block">
										<?php echo $full ? 'Join the waitlist' : 'Reserve my spot'; ?>
										<?php echo ptl_icon( 'arrow-up-right', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									</button>
									<p class="form-note">Demo form: nothing is sent or stored. In the live portal this creates an RSVP and emails the joining link.</p>
								</form>
							</div>

							<div data-rsvp-success hidden>
								<span class="rsvp-success-icon" aria-hidden="true"><?php echo ptl_icon( 'check-circle', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
								<p class="eyebrow"><?php echo $full ? 'Waitlisted' : "You're in"; ?></p>
								<h2 class="rsvp-title"><?php echo $full ? "You're on the waitlist." : 'Your spot is saved.'; ?></h2>
								<p class="rsvp-copy">
									<?php echo $full ? "The circle is full right now. We'd email you if a place opens up." : 'We would send the joining link by email. This demo does not send or store anything.'; ?>
								</p>
								<dl class="rsvp-recap">
									<div>
										<dt>Circle</dt>
										<dd><?php echo esc_html( get_the_title() ); ?></dd>
									</div>
									<div>
										<dt>When</dt>
										<dd><?php echo esc_html( ptl_format_long_date( $start ) ); ?></dd>
									</div>
									<div>
										<dt>Time</dt>
										<dd><?php echo esc_html( ptl_format_time_range( $start, $end ) ); ?></dd>
									</div>
									<div>
										<dt>Email</dt>
										<dd data-rsvp-recap-email>—</dd>
									</div>
								</dl>
								<button type="button" class="btn btn-primary btn-block" data-rsvp-calendar>
									<?php echo ptl_icon( 'download', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									Add to calendar
								</button>
								<button type="button" class="btn btn-ghost btn-block" data-rsvp-reset>
									<?php echo ptl_icon( 'x', 15 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									Cancel my RSVP
								</button>
							</div>
						<?php endif; ?>
					</div>

					<div class="aside-note">
						<strong>Not sure if this is for you?</strong>
						<p><a href="<?php echo esc_url( ptl_page_url( 'ask' ) ); ?>">Ask us first</a> — you don't have to commit to a circle to ask a question.</p>
					</div>
				</aside>
			</div>
		</div>
	</article>
	<?php
endwhile;

get_footer();
