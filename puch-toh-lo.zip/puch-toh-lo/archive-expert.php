<?php
/**
 * Expert directory.
 *
 * @package PuchTohLo
 */

get_header();

$experts = ptl_get_experts();
$groups  = array(
	'all'            => 'Everyone',
	'Therapist'      => 'Therapists',
	'Coach'          => 'Coaches',
	'Facilitator'    => 'Facilitators',
	'Peer supporter' => 'Peer support',
	'Nutritionist'   => 'Nutrition',
);

$aside = '<div class="page-head-note">' . ptl_icon( 'shield-check', 20 ) . '<p>Credentials are checked where they apply. Peer supporters are clearly marked as non-clinical.</p></div>';

ptl_page_head(
	'The directory',
	"One directory.<br>Different kinds of help.",
	'Therapists, coaches, facilitators, nutritionists and peer supporters. Filter by what you need — not by the label you think you should search for.',
	$aside
);
?>

<div class="container">
	<div class="directory-toolbar">
		<div class="search-wrap">
			<?php echo ptl_icon( 'search', 17 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<input type="search" placeholder="Search by concern, language or name" aria-label="Search practitioners" data-expert-search>
		</div>
		<div class="segmented segmented--sm" role="group" aria-label="Session mode" data-expert-modes>
			<button type="button" class="segment is-active" data-mode="all" aria-pressed="true">Any mode</button>
			<button type="button" class="segment" data-mode="Online" aria-pressed="false">Online</button>
			<button type="button" class="segment" data-mode="In person" aria-pressed="false">In person</button>
		</div>
	</div>

	<div class="filter-row filter-row--groups" role="group" aria-label="Practitioner type" data-expert-groups>
		<?php foreach ( $groups as $id => $label ) : ?>
			<button type="button" class="filter-chip <?php echo 'all' === $id ? 'is-active' : ''; ?>" data-group="<?php echo esc_attr( $id ); ?>" aria-pressed="<?php echo 'all' === $id ? 'true' : 'false'; ?>">
				<?php echo esc_html( $label ); ?>
			</button>
		<?php endforeach; ?>
	</div>

	<div class="results-row">
		<p data-expert-count>
			<?php echo esc_html( count( $experts ) ); ?> <?php echo 1 === count( $experts ) ? 'practitioner' : 'practitioners'; ?>
		</p>
		<span>Sample profiles for design review</span>
	</div>

	<?php if ( $experts ) : ?>
		<div class="expert-grid expert-grid--directory" data-expert-grid>
			<?php foreach ( $experts as $expert ) : ?>
				<?php
				$search = implode(
					' ',
					array(
						get_the_title( $expert ),
						ptl_meta( $expert->ID, 'role' ),
						ptl_meta( $expert->ID, 'headline' ),
						implode( ' ', ptl_lines( $expert->ID, 'focus' ) ),
						implode( ' ', ptl_lines( $expert->ID, 'modalities' ) ),
						implode( ' ', ptl_lines( $expert->ID, 'languages' ) ),
					)
				);
				$attrs = sprintf(
					'data-group="%s" data-mode="%s" data-search="%s"',
					esc_attr( ptl_meta( $expert->ID, 'group' ) ),
					esc_attr( ptl_meta( $expert->ID, 'mode' ) ),
					esc_attr( strtolower( $search ) )
				);
				ptl_expert_card( $expert, $attrs );
				?>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<div data-expert-empty <?php echo $experts ? 'hidden' : ''; ?>>
		<?php
		ptl_empty_state(
			'No one matches that yet',
			'Try a different concern or language. The directory is small on purpose, and growing.',
			'<button type="button" class="btn btn-outline" data-expert-reset>Clear filters</button>'
		);
		?>
	</div>

	<section class="practitioner-band">
		<div>
			<p class="eyebrow">For practitioners</p>
			<h2 class="h2">You belong in this directory.</h2>
			<p>
				If you work with people — as a therapist, coach, facilitator, nutritionist
				or peer supporter — tell us about your modalities and how you work.
				Applications are reviewed by a human, and credentials are checked where
				they apply.
			</p>
		</div>
		<div class="practitioner-actions">
			<a href="<?php echo esc_url( ptl_page_url( 'ask' ) . '?path=practitioner' ); ?>" class="btn btn-primary">
				Apply to join
				<?php echo ptl_icon( 'arrow-up-right', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</a>
			<span class="practitioner-note">Every application is read by a person, not a form filter.</span>
		</div>
	</section>
</div>

<?php
get_footer();
