<?php
/**
 * Puch Toh Lo theme bootstrap.
 *
 * @package PuchTohLo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'PTL_VERSION', '0.1.0' );

require get_template_directory() . '/inc/icons.php';
require get_template_directory() . '/inc/helpers.php';
require get_template_directory() . '/inc/cpts.php';
require get_template_directory() . '/inc/meta.php';
require get_template_directory() . '/inc/seed.php';

/**
 * Theme supports.
 */
function ptl_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );

	register_nav_menus(
		array(
			'primary' => __( 'Primary navigation', 'puch-toh-lo' ),
		)
	);
}
add_action( 'after_setup_theme', 'ptl_setup' );

/**
 * Assets.
 */
function ptl_assets() {
	wp_enqueue_style(
		'ptl-fonts',
		'https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700&family=DM+Serif+Display:ital@0;1&family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;0,9..144,600;1,9..144,400&family=Instrument+Sans:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Inter:wght@400;500;600&display=swap',
		array(),
		null
	);

	wp_enqueue_style( 'ptl-base', get_stylesheet_uri(), array(), PTL_VERSION );
	wp_enqueue_style( 'ptl-wp', get_template_directory_uri() . '/assets/css/wp.css', array( 'ptl-base' ), PTL_VERSION );
	wp_enqueue_script( 'ptl-app', get_template_directory_uri() . '/assets/js/app.js', array(), PTL_VERSION, true );
}
add_action( 'wp_enqueue_scripts', 'ptl_assets' );

/**
 * Keep the demo clean for client review.
 */
add_filter( 'show_admin_bar', '__return_false' );

/**
 * Document metadata and pre-paint design switch.
 */
function ptl_head_meta() {
	$description = 'A quieter corner of the internet for honest questions about feelings, relationships and everyday mental health. Circles, conversations and a directory of practitioners.';
	?>
	<meta name="description" content="<?php echo esc_attr( $description ); ?>">
	<meta name="theme-color" content="#f5efe4">
	<meta property="og:title" content="Puch Toh Lo — Ask. Listen. Belong.">
	<meta property="og:description" content="<?php echo esc_attr( $description ); ?>">
	<meta property="og:type" content="website">
	<link rel="icon" type="image/svg+xml" href="<?php echo esc_url( get_template_directory_uri() . '/assets/images/favicon.svg' ); ?>">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<script>
		try {
			var query = new URLSearchParams(window.location.search).get("design");
			var saved = window.localStorage.getItem("ptl.design.v1");
			var design = query || saved;
			if (design !== "calm" && design !== "modern" && design !== "bold") {
				design = "calm";
			}
			document.documentElement.dataset.design = design;
		} catch (error) {}
	</script>
	<?php
}
add_action( 'wp_head', 'ptl_head_meta', 1 );

/**
 * Sensible defaults when the theme is activated.
 */
function ptl_activation_defaults() {
	if ( ! get_option( 'blogname' ) || 'WordPress' === get_option( 'blogname' ) ) {
		update_option( 'blogname', 'Puch Toh Lo' );
	}
	if ( ! get_option( 'blogdescription' ) || 'Just another WordPress site' === get_option( 'blogdescription' ) ) {
		update_option( 'blogdescription', 'Ask. Listen. Belong.' );
	}
	update_option( 'timezone_string', 'Asia/Kolkata' );
	update_option( 'date_format', 'j F Y' );
	update_option( 'default_comment_status', 'closed' );
	update_option( 'default_ping_status', 'closed' );

	ptl_seed_content();
}
add_action( 'after_switch_theme', 'ptl_activation_defaults' );

/**
 * Add a helpful link in the toolbar when someone is signed in.
 */
function ptl_admin_notice() {
	if ( ! current_user_can( 'edit_posts' ) ) {
		return;
	}
	?>
	<div class="ptl-admin-tip">
		<p><strong>Editing this demo:</strong> experts, circles and conversations are regular WordPress content. Use <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=expert' ) ); ?>">Experts</a>, <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=event' ) ); ?>">Circles &amp; events</a> and <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=conversation' ) ); ?>">Conversations</a>. Forms on the site are presentation-only.</p>
	</div>
	<?php
}
add_action( 'admin_notices', 'ptl_admin_notice' );
